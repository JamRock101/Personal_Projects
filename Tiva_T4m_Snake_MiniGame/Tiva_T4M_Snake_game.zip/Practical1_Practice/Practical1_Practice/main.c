#include "G8RTOS/G8RTOS.h"
#include "./MultimodDrivers/multimod.h"
#include "./threads.h"

int main(void)
{
    SysCtlClockSet(SYSCTL_SYSDIV_1 | SYSCTL_USE_OSC |
                   SYSCTL_OSC_MAIN | SYSCTL_XTAL_16MHZ);

    Multimod_Init();
    ST7789_Init();
    G8RTOS_Init();

    UARTprintf("Snake Game Running!\n");
    ST7789_Fill(0x0000); // black
    ST7789_DrawStringStatic("Press SW1 to Start Game!", 0xFFFF, 20, 140);

    // Initialize semaphores
    G8RTOS_InitSemaphore(&sem_UART, 1);
    G8RTOS_InitSemaphore(&sem_SPIA, 1);
    G8RTOS_InitSemaphore(&sem_I2CA, 1);
    G8RTOS_InitSemaphore(&sem_PCA9555_Debounce, 0);

    // Threads
    G8RTOS_AddThread(&Idle_Thread, 255, "idle\0");
    G8RTOS_AddThread(&Snake_Game_Thread, 4, "snake\0");
    G8RTOS_AddThread(&Joystick_Read_Thread, 3, "joystick\0");
    G8RTOS_AddThread(&Read_Buttons, 3, "buttons\0");

    // Button interrupt
    G8RTOS_Add_APeriodicEvent(GPIOE_Handler, 2, 20);

    UARTprintf("Press SW1 to start the game.\n");
    G8RTOS_Launch();
}
