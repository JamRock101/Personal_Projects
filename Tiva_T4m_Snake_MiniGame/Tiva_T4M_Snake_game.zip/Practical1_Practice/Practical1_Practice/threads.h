// threads.h
// Date Created: 2023-07-26
// Date Updated: 2023-07-26
// Threads

#ifndef THREADS_H_
#define THREADS_H_

/************************************Includes***************************************/

#include "./G8RTOS/G8RTOS_Semaphores.h"

/************************************Includes***************************************/
#define SPAWNCOOR_FIFO 0
#define JOYSTICK_FIFO 1
#define EXTRACREDIT_FIFO 2
/***********************************Semaphores**************************************/

//extern semaphore_t sem_UART;
//extern semaphore_t sem_I2CA;
//extern semaphore_t sem_KillCube;
//extern semaphore_t sem_Joystick_Debounce;
//extern semaphore_t sem_PCA9555_Debounce;
//extern semaphore_t sem_SPIA;


/***********************************Semaphores**************************************/


/********************************Thread Functions***********************************/
void task0(void);
void task1(void);
void task2(void);

void Idle_Thread(void);
void CamMove_Thread(void);
void Cube_Thread(void);
void Read_Buttons();
void Read_JoystickPress();
void Print_WorldCoords(void);
void Get_Joystick(void);
void GPIOE_Handler();
void GPIOD_Handler();
void Sacrifice_Thread();
void KillRandomCube();
void Shape_Drawer_Thread(void);

void Mode_Controller_Thread(void);
void Square_Control_Thread(void);

void Rotate_Square_Thread(void);

void Joystick_Read_Thread(void);

void Square_Move_Thread(void);

void Circle_Control_Thread(void);

void Circle_Move_Thread(void);

void Bouncing_Triangle_Thread(void);

void BrickBreaker_Thread(void);

void Snake_Game_Thread(void);

void Dino_Game_Thread(void);

void Mario_Thread(void);
void Barrel_Spawner(void);
void Barrel_Manager(void);

void Car_Manager(void);
void Frogger_Thread(void);

/********************************Thread Functions***********************************/
/**************Extra_Credit_Functions***********************************************/
void Extra_Credit_Thread_Get(void);
void Extra_Credit_Thread_Out(void);

#endif /* THREADS_H_ */

