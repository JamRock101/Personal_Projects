#include "./threads.h"
#include "./MultimodDrivers/multimod.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

/*************** Colors ***************/

#define C_BLACK        0x0000  // (R=0,   G=0,   B=0)
#define C_WHITE        0xFFFF  // Inverse of BLACK  (R=255, G=255, B=255)

#define C_RED          0xF800  // (R=255, G=0,   B=0)
#define C_CYAN         0x07FF  // Inverse of RED    (R=0,   G=255, B=255)

#define C_GREEN        0x07E0  // (R=0,   G=255, B=0)
#define C_MAGENTA      0xF81F  // Inverse of GREEN  (R=255, G=0,   B=255)

#define C_BLUE         0x001F  // (R=0,   G=0,   B=255)
#define C_YELLOW       0xFFE0  // Inverse of BLUE   (R=255, G=255, B=0)

#define C_GRAY         0x8410  // (R=128, G=128, B=128)
#define C_LIGHTGRAY    0xC618  // Inverse of


/*************** Semaphores ***************/
semaphore_t sem_UART = 1;
semaphore_t sem_SPIA = 1;
semaphore_t sem_I2CA = 1;
semaphore_t sem_PCA9555_Debounce = 0;

#define GRID_SIZE      10      // each cell 6x6 pixels
#define MAX_SEGMENTS  100     // snake max length
#define INIT_LENGTH     2
#define MOVE_DELAY_MS 100     // movement tick (lower = faster)


typedef enum { GAME_IDLE=0, GAME_PLAYING, GAME_OVER } game_state_t; // custom ENUMs holding the game state
volatile game_state_t g_state = GAME_IDLE;

typedef struct {
    int x;
    int y;
} Point;

typedef enum { DIR_UP, DIR_DOWN, DIR_LEFT, DIR_RIGHT } Direction;

Point snake[MAX_SEGMENTS];
int snake_length;
Direction dir;
Point apple;

static void DrawCell(int x, int y, uint16_t color)
{
    // Draw a single grid block (filled square)
    ST7789_DrawRectangle(x, y, GRID_SIZE, GRID_SIZE, color);
}

static void DrawCircle(int cx, int cy, int r, uint16_t color)
{
    for (int y = -r; y <= r; y++) {
        for (int x = -r; x <= r; x++) {
            if (x*x + y*y <= r*r)
                ST7789_DrawPixel(cx + x, cy + y, color);
        }
    }
}

static void ResetGame(void)
{

    // brings back to original state
    snake_length = INIT_LENGTH;
    int startX = X_MAX / 2;
    int startY = Y_MAX / 2;

    for (int i = 0; i < snake_length; i++) {
        snake[i].x = startX - i * GRID_SIZE;
        snake[i].y = startY;
    }

    dir = DIR_RIGHT;

    // spawn apple randomly
    apple.x = (rand() % ((X_MAX - 2*GRID_SIZE)/GRID_SIZE)) * GRID_SIZE + GRID_SIZE;
    apple.y = (rand() % ((Y_MAX - 2*GRID_SIZE)/GRID_SIZE)) * GRID_SIZE + GRID_SIZE;

    G8RTOS_WaitSemaphore(&sem_SPIA);
    ST7789_Fill(C_WHITE); // fill white because its the inverse of black
    // Draw snake
    for (int i = 0; i < snake_length; i++)
        DrawCell(snake[i].x, snake[i].y, C_MAGENTA); // set as magenta as it is the opposite of green
    // Draw head circle
    DrawCircle(snake[0].x + GRID_SIZE/2, snake[0].y + GRID_SIZE/2, GRID_SIZE/2, C_MAGENTA); // set as magenta as it is the opposite of green
    // Draw apple
    DrawCircle(apple.x + GRID_SIZE/2, apple.y + GRID_SIZE/2, GRID_SIZE/2, C_CYAN); // set as cyan as it is the opposite of red
    G8RTOS_SignalSemaphore(&sem_SPIA);
}

static bool CollidedWithSelf(void) // checks if the snake head is on same position pixel as itself
{
    for (int i = 1; i < snake_length; i++) {
        if (snake[0].x == snake[i].x && snake[0].y == snake[i].y)
            return true;
    }
    return false;
}

static bool CollidedWithWall(void) // checks if the snake head is on same position pixel as boundaries of the LCD screen
{
    return (snake[0].x < 0 || snake[0].x >= X_MAX ||
            snake[0].y < 0 || snake[0].y >= Y_MAX);
}

void Idle_Thread(void)
{
    while(1){


    }
}


void Read_Buttons(void)
{
    while(1) // starts the game with S1, then
    {
        G8RTOS_WaitSemaphore(&sem_PCA9555_Debounce);
        G8RTOS_Sleep(50);

        G8RTOS_WaitSemaphore(&sem_I2CA);
        uint8_t buttons = MultimodButtons_Get();
        G8RTOS_SignalSemaphore(&sem_I2CA);

        bool sw1_pressed = !(buttons & 0x02);

        if (sw1_pressed)
        {
            g_state = GAME_PLAYING; // once game_playing is the state (it is true) the game actually begins (handled in launch thread)
            ResetGame(); // brings the snake back to its original position and size, spawns another apple
        }

        GPIOIntClear(GPIO_PORTE_BASE, GPIO_PIN_4);
        GPIOIntEnable(GPIO_PORTE_BASE, GPIO_PIN_4);
    }
}

void Joystick_Read_Thread(void)
{
    static int last_x = 2048;
    static int last_y = 2048;

    while(1)
    {
        if (g_state == GAME_PLAYING)
        {
            G8RTOS_WaitSemaphore(&sem_I2CA);
            uint32_t xy = JOYSTICK_GetXY();
            G8RTOS_SignalSemaphore(&sem_I2CA);

            int x = (xy >> 16) & 0xFFFF;
            int y = xy & 0xFFFF;

            // detect flick (large deviation from center)
            int dx = x - last_x; // detects last movement from center to understand the current direction to point in
            int dy = y - last_y;

            if (abs(dx) > 500 && abs(dx) > abs(dy))
            {
                if (dx > 0 && dir != DIR_LEFT) dir = DIR_RIGHT;
                else if (dx < 0 && dir != DIR_RIGHT) dir = DIR_LEFT;
            }
            else if (abs(dy) > 500)
            {
                if (dy > 0 && dir != DIR_UP) dir = DIR_DOWN;
                else if (dy < 0 && dir != DIR_DOWN) dir = DIR_UP;
            }

            last_x = x; // if no change the last state is equal to the current state
            last_y = y;
        }
        G8RTOS_Sleep(50);
    }
}


void Snake_Game_Thread(void)
{
    while(1)
    {
        if (g_state == GAME_PLAYING) // only starts once game_playing is true
        {

            // erase tail
            Point tail = snake[snake_length - 1];
            G8RTOS_WaitSemaphore(&sem_SPIA);
            DrawCell((tail.x), (tail.y), C_WHITE); // "eats" apple by drawing over it in black (same colour as the background)
            G8RTOS_SignalSemaphore(&sem_SPIA);

            // shift body
            for (int i = snake_length - 1; i > 0; i--)
                snake[i] = snake[i - 1];

            // move head
            switch (dir)
            {
                case DIR_UP:    snake[0].y -= GRID_SIZE; break;
                case DIR_DOWN:  snake[0].y += GRID_SIZE; break;
                case DIR_LEFT:  snake[0].x -= GRID_SIZE; break;
                case DIR_RIGHT: snake[0].x += GRID_SIZE; break;
            }

            if (CollidedWithWall() || CollidedWithSelf()) // checks for the game over condition
            {
                g_state = GAME_OVER;

                G8RTOS_WaitSemaphore(&sem_SPIA);
                ST7789_Fill(C_CYAN);
                ST7789_DrawStringStatic("You Lost Ahmed!", C_WHITE, 60, 100);
                ST7789_DrawStringStatic("(Please help me get my lab4 working)", C_WHITE, 20, 120);
                ST7789_DrawStringStatic("Press SW1 to Restart", C_WHITE, 20, 140);
                G8RTOS_SignalSemaphore(&sem_SPIA);

                G8RTOS_WaitSemaphore(&sem_UART);
                UARTprintf("You Lost!\n");
                G8RTOS_SignalSemaphore(&sem_UART);

                continue;
            }


            int snake_cx = snake[0].x + GRID_SIZE/2;
            int snake_cy = snake[0].y + GRID_SIZE/2;
            int apple_cx = apple.x + GRID_SIZE/2;
            int apple_cy = apple.y + GRID_SIZE/2;

            int dx = snake_cx - apple_cx;
            int dy = snake_cy - apple_cy;
            int dist2 = dx*dx + dy*dy;
            int hit_radius = GRID_SIZE;   // tolerance (roughly one cell)

            if (dist2 <= hit_radius * hit_radius)

            {
                if (snake_length < MAX_SEGMENTS)
                    snake_length++;

                // spawn new apple in random position after new process
                apple.x = (rand() % ((X_MAX - 2*GRID_SIZE)/GRID_SIZE)) * GRID_SIZE + GRID_SIZE;
                apple.y = (rand() % ((Y_MAX - 2*GRID_SIZE)/GRID_SIZE)) * GRID_SIZE + GRID_SIZE;

                G8RTOS_WaitSemaphore(&sem_UART);
                UARTprintf("Apple eaten! Length = %d\n", snake_length);
                G8RTOS_SignalSemaphore(&sem_UART);
            }


            G8RTOS_WaitSemaphore(&sem_SPIA);
            // draw apple
            DrawCircle(apple.x + GRID_SIZE/2, apple.y + GRID_SIZE/2, GRID_SIZE/2, C_CYAN);
            // draw head
            DrawCircle(snake[0].x + GRID_SIZE/2, snake[0].y + GRID_SIZE/2, GRID_SIZE/2, C_MAGENTA);
            // spawn body based on snake_length variable
            for (int i = 1; i < snake_length; i++)
                DrawCell(snake[i].x, snake[i].y, C_MAGENTA);
            G8RTOS_SignalSemaphore(&sem_SPIA);
        }

        G8RTOS_Sleep(MOVE_DELAY_MS);
    }
}


void GPIOE_Handler(void) // simple debounce for the buttons
{
    GPIOIntClear(GPIO_PORTE_BASE, GPIO_PIN_4);
    G8RTOS_SignalSemaphore(&sem_PCA9555_Debounce);
}
