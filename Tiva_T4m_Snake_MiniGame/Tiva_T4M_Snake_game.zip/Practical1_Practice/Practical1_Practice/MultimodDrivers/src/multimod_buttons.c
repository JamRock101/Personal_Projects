// multimod_buttons.c
// Date Created: 2023-07-25
// Date Updated: 2023-07-27
// Defines for button functions

/************************************Includes***************************************/

#include "../multimod_buttons.h"

#include "../multimod_i2c.h"

#include <driverlib/gpio.h>
#include <driverlib/sysctl.h>
#include <driverlib/pin_map.h>
#include <driverlib/i2c.h>

#include <inc/tm4c123gh6pm.h>
#include <inc/hw_i2c.h>

/************************************Includes***************************************/
#define Input_port0_config_reg 0x6

/********************************Public Functions***********************************/

// check page 22 of Multimod Schematic for PCA9555PW for tactile switches



// Buttons_Init
// Initializes buttons on the multimod by configuring the I2C module and
// relevant interrupt pin.
// Return: void
void MultimodButtons_Init() {
    // your code
    I2C_Init(1);
//    I2C_WriteSingle(0, Input_port0_config_reg, 0xff); // configure input0 as an input


    // enable relelavant interrupt pin

    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOE);
    while (!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOE));

    GPIOPinTypeGPIOInput(BUTTONS_INT_GPIO_BASE, BUTTONS_INT_PIN); // enable the interrupt pin (PE4) for the GPIOEhandler
  // this function seems to be giving some issues, try filling gpiohandlerE

    GPIOPadConfigSet(BUTTONS_INT_GPIO_BASE, BUTTONS_INT_PIN, GPIO_STRENGTH_2MA, GPIO_PIN_TYPE_STD_WPU);
    GPIOIntDisable(BUTTONS_INT_GPIO_BASE, BUTTONS_INT_PIN);        // Disable during config
    GPIOIntClear(BUTTONS_INT_GPIO_BASE, BUTTONS_INT_PIN);          // Clear any pending
    GPIOIntTypeSet(BUTTONS_INT_GPIO_BASE, BUTTONS_INT_PIN, GPIO_FALLING_EDGE); // Falling edge
    GPIOIntEnable(BUTTONS_INT_GPIO_BASE, BUTTONS_INT_PIN);         // Enable pin interrupt
    IntEnable(INT_GPIOE);




}

// MultimodButtons_Get
// Gets the input to GPIO bank 1, [0..7].
// Return: uint8_t 
uint8_t MultimodButtons_Get() {
    // your code

    uint8_t value;

    I2C_WriteSingle(1, BUTTONS_PCA9555_GPIO_ADDR, 0); // port-A I2C base, sends 0x0 to access input port0
    value = I2C_ReadSingle(1, BUTTONS_PCA9555_GPIO_ADDR); // port-A I2C base, sends 0x0 to access input port0

    return value;


}

/********************************Public Functions***********************************/

