import cv2
import numpy as np


BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (0, 0, 255)
GREEN = (0, 255, 0)
BLUE = (255, 0, 0)
CYAN = (255, 255, 0)
MAGENTA = (255, 0, 255)
YELLOW = (0, 255, 255)
p0 = 100, 10
p1 = 200, 90
p2 = 300, 20    
p3 = 450, 80

img = cv2.imread('path_to_image/input.png')# input image
canvas = np.zeros((100, 500, 3), np.uint8) # blank canvas
# Draw rectangles on the canvas
cv2.rectangle(img, p0, p1, BLUE, 2)
cv2.rectangle(img, p2, p3, GREEN, cv2.FILLED)
# Draw rectangles on the canvas
cv2.rectangle(img, p0, p1, BLUE, 2)
cv2.rectangle(img, p2, p3, GREEN, cv2.FILLED)
# Show the image on a window
cv2.imshow('Window Name', canvas)
cv2.waitKey(0)
cv2.destroyAllWindows()
# Save the image
cv2.imwrite('path_to_image/output.png', img)
