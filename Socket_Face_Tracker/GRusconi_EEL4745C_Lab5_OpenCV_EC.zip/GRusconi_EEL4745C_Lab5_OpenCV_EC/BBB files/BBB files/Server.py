import socket
import pickle
import struct

if __name__ == "__main__":
    # Specify IP Host and Port
    HOST = "0.0.0.0"  # Listen on all interfaces
    PORT = 12345      # Port to listen on

    # Create socket
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    # Bind port and begin listening for a connection
    server_socket.bind((HOST, PORT))
    server_socket.listen(1)
    print(f"Server listening on {HOST}:{PORT}...")

    try:
        # Accept connection from a client
        conn, addr = server_socket.accept()
        print(f"Connection established with {addr}")

        # Send a random message to the client
        message = "Hello from the server!"
        conn.sendall(message.encode("utf-8"))
        print(f"Message sent: {message}")

        # Continuously receive data from the client
        while True:
            # Receive data from the client
            data = conn.recv(1024)  # Adjust buffer size as needed
            if not data:
                print("Client disconnected.")
                break

            # Unpack and display the received data
            try:
                unpacked_data = pickle.loads(data)
                print(f"Data received: {unpacked_data}")
            except Exception as e:
                print(f"Error unpacking data: {e}")

    except Exception as e:
        print(f"Error: {e}")
    finally:
        # Close the server
        conn.close()
        print("Connection closed.")