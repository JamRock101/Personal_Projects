import socket
from random import randint
from time import sleep
import pickle
import struct
import serial
import socket

from struct import *


if __name__ == "__main__":
    # Specify IP Host and Port
    #HOST = "192.168.1.122"  # Replace with your server's IP address
    HOST = "192.168.7.1"
    #PORT = 12345          # Same port as the server
    PORT = 12345

    # Connect to socket
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    try:
        # Connect to the server
        client_socket.connect((HOST, PORT))
        print("Connected to server at {}:{}".format(HOST, PORT))

        # Receive message from server
        data = client_socket.recv(1024)
        print("Message received: {}".format(data.decode('utf-8')))

        # Simulate sending random data back to the server if needed
        while True:
            # Create a random set of values for packaging
            random_data = [randint(0, 100) for _ in range(5)]
            packaged_data = pickle.dumps(random_data)

            # Package and send data
            client_socket.sendall(packaged_data)
            print("Data sent: {}".format(random_data))

            # Add delay
            sleep(5)
    except Exception as e:
        print("Error: {}".format(e))
    finally:
        # Close the client socket
        client_socket.close()
        print("Connection closed.")