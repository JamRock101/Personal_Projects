import serial
import time

# -------------------------------------------------------
# BeagleBone UART test script
# Continuously sends "Hello world" to the Tiva via UART4
# -------------------------------------------------------

# Change device name if needed: /dev/ttyS4 (new) or /dev/ttyO4 (old)
uart_port = "/dev/ttyS4"
baud_rate = 115200

# Open UART port
ser = serial.Serial(uart_port, baud_rate, timeout=1)
print(f"Opened {uart_port} at {baud_rate} baud.")

try:
    while True:
        msg = "Hello world\n"
        ser.write(msg.encode())      # send text
        print(f"Sent: {msg.strip()}")
        time.sleep(0.5)              # 2 Hz update rate

except KeyboardInterrupt:
    print("\nStopping transmission.")
finally:
    ser.close()
    print("UART closed.")
