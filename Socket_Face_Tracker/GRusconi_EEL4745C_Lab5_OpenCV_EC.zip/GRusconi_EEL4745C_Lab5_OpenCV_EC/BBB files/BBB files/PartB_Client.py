import serial, random, time

uart_port = "/dev/ttyS4"
baud_rate = 115200

ser = serial.Serial(uart_port, baud_rate)
print(f"Opened {uart_port} at {baud_rate} baud")

while True:
    # Generate 7 random bytes
    data = [random.randint(0, 255) for _ in range(7)]
    ser.write(bytes(data))
    print("Sent:", data)
    time.sleep(0.5)
