import cv2 as cv2
import numpy as np

BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (0, 0, 255)
GREEN = (0, 255, 0)
BLUE = (255, 0, 0)

CYAN = (255, 255, 0)
MAGENTA = (255, 0, 255)
YELLOW = (0, 255, 255)

p0 = 100, 10
p1 = 200, 90
p2 = 300, 20    
p3 = 450, 80

img = cv2.imread('data/board_f23.jpg')# input image BGR
print(img.shape) # (3022 x 3837 x 3)

img = cv2.resize(img, (640, 480))
print(img.shape)

canvas = np.ones((100, 500, 3), np.uint8) # blank canvas
print(canvas.shape)

# Draw rectangles on the canvas
cv2.rectangle(canvas, p0, p1, BLUE, 2)
cv2.rectangle(canvas, p2, p3, GREEN, cv2.FILLED)

# Draw rectangles on the canvas
cv2.rectangle(img, p0, p1, BLUE, 2)
cv2.rectangle(img, p2, p3, GREEN, cv2.FILLED)

# Show the image on a window
cv2.imshow('Window Name', canvas)
cv2.waitKey(0)
cv2.destroyAllWindows()

# Save the image
cv2.imwrite('data/output_board.png', img)
