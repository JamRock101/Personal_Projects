#!/usr/bin/env python3
import socket
import serial
import struct
import time
import sys

HOST = "0.0.0.0"       # listen on all interfaces
PORT = 12345
UART_PORT = "/dev/ttyS4"
BAUD = 115200

# ----- UART setup -----
try:
    ser = serial.Serial(UART_PORT, BAUD, timeout=1)
    print(f"[INFO] UART open on {UART_PORT} @ {BAUD}")
except Exception as e:
    print(f"[ERROR] UART open failed: {e}")
    sys.exit(1)

# ----- TCP server setup -----
server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
server.bind((HOST, PORT))
server.listen(1)

print(f"[INFO] Waiting for laptop on port {PORT} ...")
conn, addr = server.accept()
print(f"[INFO] Connected to laptop: {addr}")

buffer = bytearray()
PACKET_SIZE = 2  # x, y

while True:
    try:
        chunk = conn.recv(64)
        if not chunk:
            print("[WARN] Client disconnected")
            conn.close()
            print("[INFO] Waiting for reconnection...")
            conn, addr = server.accept()
            print(f"[INFO] Reconnected: {addr}")
            buffer = bytearray()
            continue

        buffer.extend(chunk)

        # Process full (x,y) packets
        while len(buffer) >= PACKET_SIZE:
            pkt = buffer[:PACKET_SIZE]
            buffer = buffer[PACKET_SIZE:]

            try:
                x, y = struct.unpack("2B", pkt)
                print(f"[RX] x={x}, y={y}")

                # Alternate sending: x then y
                ser.write(bytes([x]))
                ser.write(bytes([y]))
            except struct.error:
                print("[ERROR] Bad packet, skipping")
                continue

    except KeyboardInterrupt:
        print("\n[INFO] Stopping...")
        break
    except Exception as e:
        print(f"[ERROR] Lost connection: {e}")
        conn.close()
        print("[INFO] Waiting for reconnection...")
        conn, addr = server.accept()
        print(f"[INFO] Reconnected: {addr}")
        buffer = bytearray()

conn.close()
ser.close()
server.close()
print("[INFO] BBB bridge closed.")
