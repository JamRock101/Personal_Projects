import cv2
import socket
import struct
import time
import os
import argparse

HOST = "192.168.7.2"   # BBB IP
PORT = 12345
LCD_W, LCD_H = 240, 280
SEND_INTERVAL = 0.05

def connect_to_bbb():
    while True:
        try:
            print(f"[INFO] Connecting to BBB at {HOST}:{PORT}...")
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            sock.connect((HOST, PORT))
            print("[INFO] Connected!")
            return sock
        except Exception as e:
            print("[WARN] Connection failed, retrying in 2 sec...", e)
            time.sleep(2)

def send_xy(sock, x, y):
    try:
        pkt = struct.pack("2B", x, y)   # ONLY x, y
        sock.sendall(pkt)
        return True
    except Exception as e:
        print("[WARN] send_xy failed:", e)
        return False

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--casc_Path",
                        default="haarcascade_frontalface_default.xml")
    args = parser.parse_args()

    script_dir = os.path.dirname(os.path.abspath(__file__))
    cascPath = os.path.join(script_dir, args.casc_Path)
    print("Using cascade:", cascPath)

    if not os.path.exists(cascPath):
        raise FileNotFoundError("Cascade file not found")
    faceCascade = cv2.CascadeClassifier(cascPath)
    if faceCascade.empty():
        raise IOError("Failed to load cascade")

    sock = connect_to_bbb()

    cap = cv2.VideoCapture(0)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
    if not cap.isOpened():
        raise RuntimeError("Camera failed to open")

    print("[INFO] Webcam opened")

    while True:
        ret, frame = cap.read()
        if not ret:
            continue

        frame = cv2.resize(frame, (640, 480))
        gray  = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = faceCascade.detectMultiScale(gray, 1.3, 5)

        for (x, y, w, h) in faces:
            cv2.rectangle(frame, (x, y), (x + w, y + h), (255, 0, 0), 2)

        cv2.imshow("Face Detection", frame)

        if len(faces) > 0:
            (x, y, w, h) = faces[0]
            H, W, _ = frame.shape  # H=480, W=640

            x_lcd = int(x / W * LCD_W)
            y_lcd = int(y / H * LCD_H)

            x_lcd = max(0, min(255, x_lcd))
            y_lcd = max(0, min(255, y_lcd))
        else:
            # No face – send 0,0 (you can change this if you want)
            x_lcd, y_lcd = 0, 0

        if not send_xy(sock, x_lcd, y_lcd):
            sock.close()
            sock = connect_to_bbb()

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

        time.sleep(SEND_INTERVAL)

    cap.release()
    sock.close()
    cv2.destroyAllWindows()
    print("[INFO] Closed cleanly.")

if __name__ == "__main__":
    main()
