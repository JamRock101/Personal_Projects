import cv2
import sys
import argparse
import os.path as path

from face_detect_img import face_detect, draw_face_boxes


if __name__=="__main__":

    parser = argparse.ArgumentParser()
    parser.add_argument("--video_path", type=str, default="data/test_video.mp4")
    parser.add_argument("--casc_Path", type=str, default="haarcascade_frontalface_default.xml")
    args = parser.parse_args()

    # Get user supplied values
    videoPath = args.video_path
    cascPath = args.casc_Path

    if not path.exists(videoPath):
        print ("Video is not found!")
    else:
        vidObj = cv2.VideoCapture(videoPath)

        # Create the haar cascade
        faceCascade = cv2.CascadeClassifier(cascPath)

        out_video_name = videoPath.replace(".", "_out.")

        out_video = cv2.VideoWriter(out_video_name, cv2.VideoWriter_fourcc(*'mp4v'), 30, (320,240))

        success = True
        while(success):
            success, image = vidObj.read()
            if success:
                image_resized =  cv2.resize(image,(320,240))
                faces = face_detect(image_resized, faceCascade)
                image_out = draw_face_boxes(image_resized, faces)
                out_video.write(image_out)
        
        out_video.release()



