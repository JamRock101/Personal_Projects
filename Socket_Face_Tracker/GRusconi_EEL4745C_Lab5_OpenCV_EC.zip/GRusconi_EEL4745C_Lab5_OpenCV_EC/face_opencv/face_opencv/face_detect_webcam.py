import cv2
import argparse
from time import sleep
import os

from face_detect_img import face_detect, draw_face_boxes

if __name__ == "__main__":

    parser = argparse.ArgumentParser()
    parser.add_argument("--out_path", type=str, default="data/webcam_out.mp4")
    parser.add_argument("--casc_Path", type=str, default="haarcascade_frontalface_default.xml")
    args = parser.parse_args()

    out_video_name = args.out_path

    # ------------------------------------------------------------------
    # 🔧 FIXED SECTION: build absolute path to haarcascade file
    script_dir = os.path.dirname(os.path.abspath(__file__))
    cascPath = os.path.join(script_dir, args.casc_Path)

    print("Looking for cascade at:", cascPath)
    if not os.path.exists(cascPath):
        raise FileNotFoundError(f"Cannot find cascade file: {cascPath}")

    faceCascade = cv2.CascadeClassifier(cascPath)
    if faceCascade.empty():
        raise IOError(f"Failed to load cascade from {cascPath}")
    # ------------------------------------------------------------------

    video_capture = cv2.VideoCapture(0)
    out_video = cv2.VideoWriter(out_video_name,
                                cv2.VideoWriter_fourcc(*'mp4v'),
                                30,
                                (640, 480))   # match your frame size

    while True:
        if not video_capture.isOpened():
            print('Unable to load camera.')
            sleep(5)
            continue

        ret, frame = video_capture.read()
        frame_resized = cv2.resize(frame, (640, 480))
        faces = face_detect(frame_resized, faceCascade)
        image_out = draw_face_boxes(frame_resized, faces)

        cv2.imshow('Video', image_out)
        out_video.write(image_out)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    out_video.release()
    video_capture.release()
    cv2.destroyAllWindows()
