// G8RTOS_IPC.c
// Date Created: 2023-07-25
// Date Updated: 2023-07-27
// Defines for FIFO functions for interprocess communication

#include "../G8RTOS_IPC.h"

/************************************Includes***************************************/

#include "../G8RTOS_Semaphores.h"

/************************************Includes***************************************/

/******************************Data Type Definitions********************************/

#define FIFO_SIZE 16
#define MAX_NUMBER_OF_FIFOS 4

/******************************Data Type Definitions********************************/

/****************************Data Structure Definitions*****************************/

typedef struct G8RTOS_FIFO_t{

    int32_t buffer[16];
    int32_t *head;
    int32_t *tail;
    uint32_t lostData;
    semaphore_t currentSize;
    semaphore_t mutex;


} G8RTOS_FIFO_t;

static G8RTOS_FIFO_t FIFOs[4];

/****************************Data Structure Definitions*****************************/

/***********************************Externs*****************************************/
/***********************************Externs*****************************************/

/********************************Public Variables***********************************/

static G8RTOS_FIFO_t FIFOs[MAX_NUMBER_OF_FIFOS];

/********************************Public Variables***********************************/

/********************************Public Functions***********************************/

// G8RTOS_InitFIFO
// Initializes FIFO, points head & tai to relevant buffer
// memory addresses.
// Param "FIFO_index": Index of FIFO block
// Return: int32_t, -1 if error (i.e. FIFO full), 0 if okay
int32_t G8RTOS_InitFIFO(uint32_t FIFO_index) {

    // Invalid index check
    if (FIFO_index >= MAX_NUMBER_OF_FIFOS)
        return -1;

    G8RTOS_FIFO_t *fifo = &FIFOs[FIFO_index];

    // Initialize pointers to the buffer start
    fifo->head = &fifo->buffer[0];
    fifo->tail = &fifo->buffer[0];

    // Reset lost data counter
    fifo->lostData = 0;

    // Initialize semaphores
    fifo->currentSize = 0;  // FIFO initially empty
    fifo->mutex = 1;        // Mutex unlocked

    return 0; // success

}


// G8RTOS_ReadFIFO
// Reads data from head pointer of FIFO
// Param uint32t "FIFO_index": Index of FIFO block
// Return: int32_T

// Parameter: an int32_t value, which FIFO should be read
// Return value: an int32_t value from the head of FIFO
// Mutex semaphore:
// Wait before reading from FIFO
// In case the FIFO is being read from another thread
// Current Size semaphore:
// Wait before reading from FIFO
// In case the FIFO is empty
// When read is complete:
// Update the head pointer
// Signal the Mutex semaphore so other waiting threads can read

int32_t G8RTOS_ReadFIFO(uint32_t FIFO_index){
    // your code
    // be mindful of boundary conditions

    if (FIFO_index >= MAX_NUMBER_OF_FIFOS)
        return -1;

    G8RTOS_FIFO_t *fifo = &FIFOs[FIFO_index];
    int32_t data;

    // Wait on semaphores
    G8RTOS_WaitSemaphore(&fifo->currentSize); // Wait until not empty
    G8RTOS_WaitSemaphore(&fifo->mutex);       // Lock FIFO access

    // Read data from head
    data = *(fifo->head);

    // Move head pointer
    fifo->head++;
    if (fifo->head >= &fifo->buffer[FIFO_SIZE])
        fifo->head = &fifo->buffer[0]; // wrap around

    // Release mutex
    G8RTOS_SignalSemaphore(&fifo->mutex);

    return data;

}


// G8RTOS_WriteFIFO
// Writes data to tail of buffer
// 0 if no error, -1 if out of bounds, -2 if full
// Param uint32_t "FIFO_index": Index of FIFO block
// Param uint32_t "data": data to be written
// Return: int32_t


// Parameter:
// An int32_t value, which FIFO should be read
// An int32_t value, data to be written into the tail of FIFO
// Current Size semaphore
// The value should be compared with the FIFOSIZE-1.
// Provides 1 buffer cell in case an interrupt happens between reading FIFO and incrementing its head.
// If the value is larger than FIFOSIZE-1, increment the lost data value and overwrite the old data.
// Write the data
// Signal the Current Size semaphore and notify other waiting threads the FIFO is not empty.

int32_t G8RTOS_WriteFIFO(uint32_t FIFO_index, uint32_t data){

    // Your code

    if (FIFO_index >= MAX_NUMBER_OF_FIFOS)
        return -1;

    G8RTOS_FIFO_t *fifo = &FIFOs[FIFO_index];

    // Check if FIFO is full
    if (fifo->currentSize > FIFO_SIZE - 1)
    {
        // FIFO full: increment lost data counter and overwrite old data
        fifo->lostData++;
        *(fifo->tail) = data;

        // Move tail pointer and wrap if necessary
        fifo->tail++;
        if (fifo->tail >= &fifo->buffer[FIFO_SIZE])
            fifo->tail = &fifo->buffer[0];

        // Move head pointer too (overwrite oldest)
        fifo->head++;
        if (fifo->head >= &fifo->buffer[FIFO_SIZE])
            fifo->head = &fifo->buffer[0];

        return -2; // FIFO full, data overwritten
    }

    // Otherwise, write data normally
    *(fifo->tail) = data;

    // Move tail pointer
    fifo->tail++;
    if (fifo->tail >= &fifo->buffer[FIFO_SIZE])
        fifo->tail = &fifo->buffer[0];

    // Signal that FIFO now has one more item
    G8RTOS_SignalSemaphore(&fifo->currentSize);

    return 0; // success

}


/********************************Public Functions***********************************/
