// G8RTOS_Scheduler.c
// Date Created: 2023-07-25
// Date Updated: 2023-07-27
// Defines for scheduler functions

#include "../G8RTOS_Scheduler.h"



#include <stdint.h>/************************************Includes***************************************/

#include "../G8RTOS_CriticalSection.h"

#include "inc/hw_types.h"
#include "inc/hw_ints.h"
#include "inc/hw_nvic.h"
#include "driverlib/systick.h"
#include "driverlib/sysctl.h"
#include "driverlib/interrupt.h"

/************************************Includes***************************************/

/********************************Private Variables**********************************/

// Thread Control Blocks - array to hold information for each thread
// stuff goes here

// Thread Stacks - array of arrays for individual stacks of each thread
// stuff goes here

// Current Number of Threads currently in the scheduler
// stuff goes here

/********************************Private Variables**********************************/

#define NULL ((void *)0)



#define MAXPTHREADS 6

ptcb_t Pthread[MAXPTHREADS];   // array of periodic threads
ptcb_t *PthreadHead;           // pointer to first periodic thread (optional)

tcb_t *CurrentlyRunningThread;
uint32_t SystemTime = 0;
//uint32_t NumberOfThreads = 3;
uint32_t ThreadAdderPtr = 0;


// Thread Control Blocks - array to hold information for each thread
static tcb_t threadControlBlocks[MAX_THREADS];

// Thread Stacks - array of arrays for individual stacks of each thread
static uint32_t threadStacks[MAX_THREADS][STACKSIZE];

// Periodic Event Threads - array to hold pertinent information for each thread
static ptcb_t pthreadControlBlocks[MAX_PTHREADS];

// Current Number of Threads currently in the scheduler
static uint32_t NumberOfThreads;

// Current Number of Periodic Threads currently in the scheduler
static uint32_t NumberOfPThreads;

static uint32_t threadCounter = 0;
/*******************************Private Functions***********************************/
#define SYSTEM_CLOCK 80000000   // 80 MHz system clock
#define TICK_RATE    1000       // 1000 Hz = 1 ms tick
#define THUMBBIT 0X01000000
#define STACKSIZE 1024
#define THREAD_STATUS_ALIVE 1
#define THREAD_STATUS_DEAD 0


extern void G8RTOS_Scheduler(void);
extern void G8RTOS_Start(void);




/*******************************Private Functions***********************************/


/********************************Public Variables***********************************/



// reference currently running thread
// stuff goes here

/********************************Public Variables***********************************/



/********************************Public Functions***********************************/





// G8RTOS_Launch
// Launches the RTOS.
// Return: error codes, 0 if none
int8_t G8RTOS_Launch(void) {

    InitSysTick();

    CurrentlyRunningThread = &threadControlBlocks[0];
    // Set interrupt priorities (lowest possible)

    IntPrioritySet(FAULT_SYSTICK, 0xE0);
    IntPrioritySet(FAULT_PENDSV, 0xE0);

    // (Optional) Re-set CurrentlyRunningThread
    // It's already set by AddThread(), but safe to do again


    //IntMasterEnable();
    // Start the first thread
    G8RTOS_Start();
    // Call G8RTOS_Start()
   // while (1) { }
    return 0;
}



void G8RTOS_Scheduler(void)
{
    /**************************************************************
     * Initialize search variables
     **************************************************************/
    tcb_t *nextThread = CurrentlyRunningThread->nextTCB; // start from next thread
    tcb_t *bestThread = NULL;                            // will hold best candidate
    uint8_t currentMaxPriority = 255;                    // 255 = lowest priority
//    uint32_t currentMaxPriority = 256;                    // 255 = lowest priority
    tcb_t *start = nextThread;                           // starting point for circular search
    tcb_t *idleThread = NULL;                            // to store the idle thread (priority 255)

    /**************************************************************
     * Step 1: Traverse all threads once in circular list
     **************************************************************/

    if (!CurrentlyRunningThread->isAlive){

        G8RTOS_KillSelf();
    }

    do
    {
        // Keep track of idle thread (priority 255)
        if (nextThread->Priority == 255)
        {
            idleThread = nextThread;
        }

        // Check if this thread is runnable
        if ((nextThread->isAlive == 1) &&
            (nextThread->blocked == 0) &&
            (nextThread->asleep == 0))
        {
            // If it has a higher priority (numerically smaller), select it
            if (nextThread->Priority < currentMaxPriority)
            {
                bestThread = nextThread;
                currentMaxPriority = nextThread->Priority;
            }
        }

        nextThread = nextThread->nextTCB; // move forward
    } while (nextThread != start);

    /**************************************************************
     * Step 2: Default to Idle Thread if no runnable thread found
     **************************************************************/
    if (bestThread == NULL)
    {
        // If this is the first ever call, or all are blocked/asleep,
        // default to idle thread (priority 255)
        bestThread = idleThread;
    }

    /**************************************************************
     * Step 3: Update currently running thread
     **************************************************************/
    CurrentlyRunningThread = bestThread;
}





//void SysTick_Handler(void) // correct implementation
//{
//    /************************************************************
//     * 1. Increment system time counter
//     ************************************************************/
//    SystemTime++;
//    tcb_t *ptr = CurrentlyRunningThread;
//    ptcb_t *Pptr = &Pthread[0];
//
//    /************************************************************
//     * 2. Handle periodic (P) threads
//     *    - For each periodic thread, check if SystemTime has
//     *      reached its ExecuteTime.
//     *    - If so, run the handler and update its ExecuteTime.
//     ************************************************************/
//    for (int i = 0; i < MAXPTHREADS; i++)
//    {
//        // If the P thread exists (non-null handler)
//        if (Pptr[i].handler != 0)
//        {
//            if (SystemTime >= Pptr[i].executeTime)
//            {
//                Pptr[i].handler();                     // run the periodic event
//                Pptr[i].executeTime += Pptr[i].period; // schedule next execution
//            }
//        }
//    }
//
//    /************************************************************
//     * 3. Handle background threads (sleeping threads)
//     *    - For each TCB, if it's asleep, check its sleepCount.
//     *      If SystemTime >= sleepCount, wake it up.
//     ************************************************************/
//    for (int i = 0; i < NumberOfThreads; i++)
//    {
//        if (ptr->asleep == 1)
//        {
//            if (SystemTime >= ptr->sleepCount)
//            {
//                ptr->asleep = 0; // wake up the thread
//            }
//        }
//
//        ptr = ptr->nextTCB; // advance through circular list
//    }
//
//    /************************************************************
//     * 4. Trigger context switch
//     *    - Set PendSV pending bit to request a context switch
//     ************************************************************/
//    HWREG(NVIC_INT_CTRL) |= NVIC_INT_CTRL_PEND_SV;
//}

void SysTick_Handler(void)
{
    /************************************************************
     * 1. Increment system time counter
     ************************************************************/
    SystemTime++;
    tcb_t *ptr  = CurrentlyRunningThread;
    ptcb_t *Pptr = PthreadHead;  // use linked list head

    /************************************************************
     * 2. Handle periodic (P) threads
     ************************************************************/
    if (Pptr != NULL)
    {
        ptcb_t *start = Pptr;
        do
        {
            if (SystemTime >= Pptr->executeTime)
            {
                Pptr->handler();                      // run the periodic event
                Pptr->executeTime += Pptr->period;    // schedule next time
            }
            Pptr = Pptr->nextPTCB;
        } while (Pptr != start);
    }

    /************************************************************
     * 3. Handle sleeping threads
     ************************************************************/
    for (int i = 0; i < NumberOfThreads; i++)
    {
        if (ptr->asleep == 1 && SystemTime >= ptr->sleepCount)
            ptr->asleep = 0;
        ptr = ptr->nextTCB;
    }

    /************************************************************
     * 4. Trigger context switch
     ************************************************************/
    HWREG(NVIC_INT_CTRL) |= NVIC_INT_CTRL_PEND_SV;
}




void G8RTOS_Sleep(uint32_t durationMS) { // correction implementation
// stuff goes here

    CurrentlyRunningThread -> sleepCount = durationMS + SystemTime;
    CurrentlyRunningThread -> asleep = 1;
    HWREG(NVIC_INT_CTRL) |= NVIC_INT_CTRL_PEND_SV;


}


// Occurs every 1 ms.
static void InitSysTick(void) // correct implementation
{
    SysTickPeriodSet(SysCtlClockGet() / 1000);
    SysTickIntRegister(SysTick_Handler);
    IntRegister(FAULT_PENDSV, PendSV_Handler);
    SysTickIntEnable();
    SysTickEnable();
}

// G8RTOS_Init
// Initializes the RTOS by initializing system time.
// Return: void
void G8RTOS_Init() { // correct implementation
    uint32_t newVTORTable = 0x20000000;
    uint32_t* newTable = (uint32_t*) newVTORTable;
    uint32_t* oldTable = (uint32_t*) 0;

    for (int i = 0; i < 155; i++) {
        newTable[i] = oldTable[i];
    }

    HWREG(NVIC_VTABLE) = newVTORTable;

    SystemTime = 0;
    NumberOfThreads = 0;
    NumberOfPThreads = 0;
}




// G8RTOS_AddThread
// Adds a thread. This is now in a critical section to support dynamic threads.
// It also now should initalize priority and account for live or dead threads.
// Param void* "threadToAdd": pointer to thread function address
// Param uint8_t "priority": priority from [0, 255].
// Param char* "name": character array containing the thread name.
// Return: sched_ErrCode_t
//sched_ErrCode_t G8RTOS_AddThread(void (*threadToAdd)(void), uint8_t priority, char *name) // correct implementation
//{
//    // Enter critical section for thread-safe modification
//    uint32_t m = StartCriticalSection();
//
//    /***************************************************************
//     * 1. Check if thread limit has been reached
//     ***************************************************************/
//    if (NumberOfThreads >= MAX_THREADS)
//    {
//        EndCriticalSection(m);
//        return THREAD_LIMIT_REACHED;
//    }
//
//    /***************************************************************
//     * 2. Find an available (dead or unused) TCB slot
//     ***************************************************************/
//    int32_t index = -1;
//    for (int i = 0; i < MAX_THREADS; i++)
//    {
//        // A dead thread or one with a null stack pointer is reusable
//        if (threadControlBlocks[i].isAlive == 0 || threadControlBlocks[i].StackPointer == 0)
//        {
//            index = i;
//            break;
//        }
//    }
//
//    for (int i = 0; i < MAX_THREADS; i++) {
//            // a null sp indicates no thread present at that index
//            if (threadControlBlocks[i].StackPointer == (void*)0) {
//                index = i;
//                break;
//            }
//        }
//
//    // If no free slot found, return error
//    if (index == -1)
//    {
//        EndCriticalSection(m);
//        return THREAD_LIMIT_REACHED;
//    }
//
//    /***************************************************************
//     * 3. Initialize thread stack frame (registers + PC + xPSR)
//     ***************************************************************/
//    threadControlBlocks[index].StackPointer = &threadStacks[index][STACKSIZE - 16];
//
//    threadStacks[index][STACKSIZE - 1]  = THUMBBIT;              // xPSR
//    threadStacks[index][STACKSIZE - 2]  = (uint32_t)threadToAdd; // PC (thread function)
//    threadStacks[index][STACKSIZE - 3]  = 0x14141414;            // LR
//    threadStacks[index][STACKSIZE - 4]  = 0x12121212;            // R12
//    threadStacks[index][STACKSIZE - 5]  = 0x03030303;            // R3
//    threadStacks[index][STACKSIZE - 6]  = 0x02020202;            // R2
//    threadStacks[index][STACKSIZE - 7]  = 0x01010101;            // R1
//    threadStacks[index][STACKSIZE - 8]  = 0x00000000;            // R0
//    threadStacks[index][STACKSIZE - 9]  = 0x11111111;            // R11
//    threadStacks[index][STACKSIZE - 10] = 0x10101010;            // R10
//    threadStacks[index][STACKSIZE - 11] = 0x09090909;            // R9
//    threadStacks[index][STACKSIZE - 12] = 0x08080808;            // R8
//    threadStacks[index][STACKSIZE - 13] = 0x07070707;            // R7
//    threadStacks[index][STACKSIZE - 14] = 0x06060606;            // R6
//    threadStacks[index][STACKSIZE - 15] = 0x05050505;            // R5
//    threadStacks[index][STACKSIZE - 16] = 0x04040404;            // R4
//
//    /***************************************************************
//     * 4. Initialize TCB fields (priority, name, ID, state flags)
//     ***************************************************************/
//    tcb_t *newTCB = &threadControlBlocks[index];
//    tcb_t *lastTCB = &threadControlBlocks[NumberOfThreads - 1];
//    tcb_t *firstTCB = &threadControlBlocks[0];
//
//    newTCB->asleep = 0;
//    newTCB->blocked = 0;
//    newTCB->isAlive = 1;
//    newTCB->Priority = priority;
//    newTCB->ThreadID = index; // can use index as unique ID
//    strcpy(newTCB->ThreadName, name);
//
//    /***************************************************************
//     * 5. Insert new TCB into circular doubly linked list
//     ***************************************************************/
//    if (index == 0)
//    {
//        // First thread: points to itself
//        newTCB->nextTCB = newTCB;
//        newTCB->previousTCB = newTCB;
//    }
//    else
//    {
//        // Insert at end of list before the first thread
//
//        lastTCB->nextTCB = newTCB;
//        newTCB->previousTCB = lastTCB;
//        newTCB->nextTCB = firstTCB;
//        firstTCB->previousTCB = newTCB;
//    }
//
//    /***************************************************************
//     * 6. Increment thread count and exit critical section
//     ***************************************************************/
//    NumberOfThreads++;
//
//    EndCriticalSection(m);
//
//    return NO_ERROR;
//}


//sched_ErrCode_t G8RTOS_AddThread(void (*threadToAdd)(void), uint8_t priority, char *name) // correct implementation
//{
//    // Enter critical section for thread-safe modification
////    uint32_t m = StartCriticalSection();
//
//    /***************************************************************
//     * 1. Check if thread limit has been reached
//     ***************************************************************/
//    if (NumberOfThreads >= MAX_THREADS)
//    {
//   //     EndCriticalSection(m);
//        return THREAD_LIMIT_REACHED;
//    }
//
//    /***************************************************************
//     * 2. Find an available (dead or unused) TCB slot
//     ***************************************************************/
//    int32_t index = -1;
//    for (int i = 0; i < MAX_THREADS; i++)
//    {
//        // A dead thread or one with a null stack pointer is reusable
//        if (threadControlBlocks[i].isAlive == 0 || threadControlBlocks[i].StackPointer == 0)
//        {
//            index = i;
//            break;
//        }
//    }
//
//    for (int i = 0; i < MAX_THREADS; i++) {
//            // a null sp indicates no thread present at that index
//            if (threadControlBlocks[i].StackPointer == (void*)0) {
//                index = i;
//                break;
//            }
//        }
//
//    // If no free slot found, return error
//    if (index == -1)
//    {
//      //  EndCriticalSection(m);
//        return THREAD_LIMIT_REACHED;
//    }
//
//    /***************************************************************
//     * 3. Initialize thread stack frame (registers + PC + xPSR)
//     ***************************************************************/
//    threadControlBlocks[index].StackPointer = &threadStacks[index][STACKSIZE - 16];
//
//    threadStacks[index][STACKSIZE - 1]  = THUMBBIT;              // xPSR
//    threadStacks[index][STACKSIZE - 2]  = (uint32_t)threadToAdd; // PC (thread function)
//    threadStacks[index][STACKSIZE - 3]  = 0x14141414;            // LR
//    threadStacks[index][STACKSIZE - 4]  = 0x12121212;            // R12
//    threadStacks[index][STACKSIZE - 5]  = 0x03030303;            // R3
//    threadStacks[index][STACKSIZE - 6]  = 0x02020202;            // R2
//    threadStacks[index][STACKSIZE - 7]  = 0x01010101;            // R1
//    threadStacks[index][STACKSIZE - 8]  = 0x00000000;            // R0
//    threadStacks[index][STACKSIZE - 9]  = 0x11111111;            // R11
//    threadStacks[index][STACKSIZE - 10] = 0x10101010;            // R10
//    threadStacks[index][STACKSIZE - 11] = 0x09090909;            // R9
//    threadStacks[index][STACKSIZE - 12] = 0x08080808;            // R8
//    threadStacks[index][STACKSIZE - 13] = 0x07070707;            // R7
//    threadStacks[index][STACKSIZE - 14] = 0x06060606;            // R6
//    threadStacks[index][STACKSIZE - 15] = 0x05050505;            // R5
//    threadStacks[index][STACKSIZE - 16] = 0x04040404;            // R4
//
//    /***************************************************************
//     * 4. Initialize TCB fields (priority, name, ID, state flags)
//     ***************************************************************/
//    tcb_t *newTCB = &threadControlBlocks[index];
//    tcb_t *lastTCB = &threadControlBlocks[NumberOfThreads - 1];
//    tcb_t *firstTCB = &threadControlBlocks[0];
//
//    newTCB->asleep = 0;
//    newTCB->blocked = 0;
//    newTCB->isAlive = 1;
//    newTCB->Priority = priority;
//    newTCB->ThreadID = index; // can use index as unique ID
//    strcpy(newTCB->ThreadName, name);
//
//    /***************************************************************
//     * 5. Insert new TCB into circular doubly linked list
//     ***************************************************************/
//    if (index == 0)
//    {
//        // First thread: points to itself
//        newTCB->nextTCB = newTCB;
//        newTCB->previousTCB = newTCB;
//    }
//    else
//    {
//        // Insert at end of list before the first thread
//
//        lastTCB->nextTCB = newTCB;
//        newTCB->previousTCB = lastTCB;
//        newTCB->nextTCB = firstTCB;
//        firstTCB->previousTCB = newTCB;
//    }
//
//    /***************************************************************
//     * 6. Increment thread count and exit critical section
//     ***************************************************************/
//    NumberOfThreads++;
//
// //   EndCriticalSection(m);
//
//    return NO_ERROR;
//}

sched_ErrCode_t G8RTOS_AddThread(void (*threadToAdd)(void), uint8_t priority, char *name)
{
    uint32_t m = StartCriticalSection();

    /***************************************************************
     * 1. Find an available (dead or unused) TCB slot
     ***************************************************************/
    int32_t index = -1;

    for (int i = 0; i < MAX_THREADS; i++)
    {
        if (threadControlBlocks[i].isAlive == 0)
        {
            index = i;
            break;
        }
    }

    // If no free slot found, return error
    if (index == -1)
    {
        EndCriticalSection(m);
        return THREAD_LIMIT_REACHED;
    }

    /***************************************************************
     * 2. Initialize thread stack
     ***************************************************************/
    threadControlBlocks[index].StackPointer = &threadStacks[index][STACKSIZE - 16];

    threadStacks[index][STACKSIZE - 1]  = THUMBBIT;              // xPSR
    threadStacks[index][STACKSIZE - 2]  = (uint32_t)threadToAdd; // PC (entry)
    threadStacks[index][STACKSIZE - 3]  = 0x14141414;            // LR
    threadStacks[index][STACKSIZE - 4]  = 0x12121212;            // R12
    threadStacks[index][STACKSIZE - 5]  = 0x03030303;            // R3
    threadStacks[index][STACKSIZE - 6]  = 0x02020202;            // R2
    threadStacks[index][STACKSIZE - 7]  = 0x01010101;            // R1
    threadStacks[index][STACKSIZE - 8]  = 0x00000000;            // R0
    threadStacks[index][STACKSIZE - 9]  = 0x11111111;            // R11
    threadStacks[index][STACKSIZE - 10] = 0x10101010;            // R10
    threadStacks[index][STACKSIZE - 11] = 0x09090909;            // R9
    threadStacks[index][STACKSIZE - 12] = 0x08080808;            // R8
    threadStacks[index][STACKSIZE - 13] = 0x07070707;            // R7
    threadStacks[index][STACKSIZE - 14] = 0x06060606;            // R6
    threadStacks[index][STACKSIZE - 15] = 0x05050505;            // R5
    threadStacks[index][STACKSIZE - 16] = 0x04040404;            // R4

    /***************************************************************
     * 3. Initialize TCB fields
     ***************************************************************/
    tcb_t *newTCB = &threadControlBlocks[index];
    newTCB->asleep = 0;
    newTCB->blocked = 0;
    newTCB->isAlive = 1;
    newTCB->Priority = priority;
    newTCB->ThreadID = index;
    strcpy(newTCB->ThreadName, name);

    /***************************************************************
     * 4. Insert into circular linked list
     ***************************************************************/
    if (CurrentlyRunningThread == NULL)
    {
        // First thread being added
        newTCB->nextTCB = newTCB;
        newTCB->previousTCB = newTCB;
        CurrentlyRunningThread = newTCB;
    }
    else
    {
        // Insert just before CurrentlyRunningThread (at the end of list)
        tcb_t *last = CurrentlyRunningThread->previousTCB;

        last->nextTCB = newTCB;
        newTCB->previousTCB = last;
        newTCB->nextTCB = CurrentlyRunningThread;
        CurrentlyRunningThread->previousTCB = newTCB;
    }

    /***************************************************************
     * 5. Increment count and finish
     ***************************************************************/
    NumberOfThreads++;

    EndCriticalSection(m);
    return NO_ERROR;
}



// G8RTOS_Add_APeriodicEvent
// Param void* "AthreadToAdd": pointer to thread function address
// Param uint8_t "priority": Priorit of aperiodic event, [1..6]
// Param int32_t "IRQn": Interrupt request number that references the vector table. [0..155].
// Return: sched_ErrCode_t
sched_ErrCode_t G8RTOS_Add_APeriodicEvent(void (*AthreadToAdd)(void), uint8_t priority, int32_t IRQn) {
  // your code

        uint32_t IBit_State;

        /******************************************************************
         * 1. Enter critical section to protect NVIC configuration
         ******************************************************************/
        IBit_State = StartCriticalSection();

        /******************************************************************
         * 2. Validate parameters
         *    IRQn:  must be within 1�154 (valid user interrupts)
         *    priority: must be within 1�6 (lower number = higher priority)
         ******************************************************************/
        if ((IRQn < 1) || (IRQn > 154) || (priority < 1) || (priority > 6))
        {
            EndCriticalSection(IBit_State);
            return IRQn_INVALID;     // or use THREAD_LIMIT_REACHED / PARAM_ERR
        }

        /******************************************************************
         * 3. Get pointer to current vector table (already in SRAM)
         ******************************************************************/
        uint32_t *vectors = (uint32_t *)HWREG(NVIC_VTABLE);

        /******************************************************************
         * 4. Replace the corresponding ISR vector with the given handler
         ******************************************************************/
        vectors[IRQn] = (uint32_t)AthreadToAdd;

        /******************************************************************
         * 5. Set interrupt priority
         *    Each interrupt uses 8 bits, grouped in NVIC_PRIx registers.
         *    4 interrupts per register (PRI0, PRI1, ...).
         ******************************************************************/
        uint32_t regIndex   = IRQn / 4;          // which NVIC_PRIx register
        uint32_t shiftValue = (IRQn % 4) * 8;    // byte offset inside register
        uint32_t mask       = 0xFF << shiftValue;

        HWREG(NVIC_PRI0 + (regIndex * 4)) =
            (HWREG(NVIC_PRI0 + (regIndex * 4)) & ~mask) | ((priority << 5) << shiftValue);

        /******************************************************************
         * 6. Enable the interrupt in NVIC (unmask)
         ******************************************************************/
        HWREG(NVIC_EN0 + ((IRQn / 32) * 4)) = (1 << (IRQn % 32));

        /******************************************************************
         * 7. Exit critical section
         ******************************************************************/
        EndCriticalSection(IBit_State);

        return NO_ERROR;
}

// G8RTOS_Add_PeriodicEvent
// Adds periodic threads to G8RTOS Scheduler
// Function will initialize a periodic event struct to represent event.
// The struct will be added to a linked list of periodic events
// Param void* "PThreadToAdd": void-void function for P thread handler
// Param uint32_t "period": period of P thread to add
// Param uint32_t "execution": When to execute the periodic thread
// Return: sched_ErrCode_t
//sched_ErrCode_t G8RTOS_Add_PeriodicEvent(void (*PThreadToAdd)(void), uint32_t period, uint32_t execution) {
//    // your code
//
//    uint32_t IBit_State;
//
//    /***************************************************************
//     * 1. Enter critical section to avoid race conditions
//     ***************************************************************/
//    IBit_State = StartCriticalSection();
//
//    /***************************************************************
//     * 2. Check periodic thread limit
//     ***************************************************************/
//    if (NumberOfPThreads >= MAXPTHREADS)
//    {
//        EndCriticalSection(IBit_State);
//        return THREAD_LIMIT_REACHED;
//    }
//
//    /***************************************************************
//     * 3. Find an available (unused) periodic TCB slot
//     ***************************************************************/
//    int32_t index = -1;
//    for (int i = 0; i < MAXPTHREADS; i++)
//    {
//        if (Pthread[i].handler == 0)
//        {
//            index = i;
//            break;
//        }
//    }
//
//    if (index == -1)
//    {
//        EndCriticalSection(IBit_State);
//        return THREAD_LIMIT_REACHED;
//    }
//
//    /***************************************************************
//     * 4. Initialize this periodic thread�s fields
//     ***************************************************************/
//    Pthread[index].handler = PThreadToAdd;
//    Pthread[index].period = period;
//    Pthread[index].executeTime = execution;
//    Pthread[index].nextPTCB = NULL;
//    Pthread[index].previousPTCB = NULL;
//
//    /***************************************************************
//     * 5. Insert into the doubly-linked periodic thread list
//     ***************************************************************/
//    if (PthreadHead == NULL)
//    {
//        // First periodic thread � circular self-link
//        PthreadHead = &Pthread[index];
//        Pthread[index].nextPTCB = &Pthread[index];
//        Pthread[index].previousPTCB = &Pthread[index];
//    }
//    else
//    {
//        // Insert at end of circular linked list
//        ptcb_t *last = PthreadHead->previousPTCB;
//
//        last->nextPTCB = &Pthread[index];
//        Pthread[index].previousPTCB = last;
//        Pthread[index].nextPTCB = PthreadHead;
//        PthreadHead->previousPTCB = &Pthread[index];
//    }
//
//    /***************************************************************
//     * 6. Increment count and exit critical section
//     ***************************************************************/
//    NumberOfPThreads++;
//
//    EndCriticalSection(IBit_State);
//    return NO_ERROR;
//
//}


sched_ErrCode_t G8RTOS_Add_PeriodicEvent(void (*PThreadToAdd)(void),
                                         uint32_t period,
                                         uint32_t execution)
{
    uint32_t IBit_State = StartCriticalSection();

    if (NumberOfPThreads >= MAXPTHREADS)
    {
        EndCriticalSection(IBit_State);
        return THREAD_LIMIT_REACHED;
    }

    int32_t index = -1;
    for (int i = 0; i < MAXPTHREADS; i++)
    {
        if (Pthread[i].handler == 0)
        {
            index = i;
            break;
        }
    }
    if (index == -1)
    {
        EndCriticalSection(IBit_State);
        return THREAD_LIMIT_REACHED;
    }

    Pthread[index].handler      = PThreadToAdd;
    Pthread[index].period       = period;
    Pthread[index].executeTime  = execution;
    Pthread[index].nextPTCB         = NULL;
    Pthread[index].previousPTCB         = NULL;

    if (PthreadHead == NULL)
    {
        PthreadHead = &Pthread[index];
        Pthread[index].nextPTCB = &Pthread[index];
        Pthread[index].previousPTCB = &Pthread[index];
    }
    else
    {
        ptcb_t *last = PthreadHead->previousPTCB;
        last->nextPTCB = &Pthread[index];
        Pthread[index].previousPTCB = last;
        Pthread[index].nextPTCB = PthreadHead;
        PthreadHead->previousPTCB = &Pthread[index];
    }

    NumberOfPThreads++;
    EndCriticalSection(IBit_State);
    return NO_ERROR;
}


// G8RTOS_KillThread
// Param uint32_t "threadID": ID of thread to kill
// Return: sched_ErrCode_t
//sched_ErrCode_t G8RTOS_KillThread(threadID_t threadID) {
////    IBit_State = StartCriticalSection();
//    // Loop through tcb. If not found, return thread does not exist error. If there is only one thread running, don't kill it.
//
//    /***************************************************************
//     * 1. If only one thread exists, don�t kill it
//     ***************************************************************/
//    if (NumberOfThreads <= 1)
//    {
//        EndCriticalSection(IBit_State);
//        return CANNOT_KILL_LAST_THREAD;
//    }
//
//    /***************************************************************
//     * 2. Search for the thread with the given ID
//     ***************************************************************/
//    tcb_t *searchPtr = CurrentlyRunningThread;
//    tcb_t *threadToKill = NULL;
//
//    for (int i = 0; i < MAX_THREADS; i++)
//    {
//        if (threadControlBlocks[i].isAlive == 1 &&
//            threadControlBlocks[i].ThreadID == threadID)
//        {
//            threadToKill = &threadControlBlocks[i];
//            break;
//        }
//    }
//
//    // If thread not found
//    if (threadToKill == NULL)
//    {
//        EndCriticalSection(IBit_State);
//        return THREAD_DOES_NOT_EXIST;
//    }
//
//    /***************************************************************
//     * 3. Update alive status and remove from linked list
//     ***************************************************************/
//    threadToKill->isAlive = 0;
//
//    // Fix circular linked list pointers
//    threadToKill->previousTCB->nextTCB = threadToKill->nextTCB;
//    threadToKill->nextTCB->previousTCB = threadToKill->previousTCB;
//
//    NumberOfThreads--;
//
//    /***************************************************************
//     * 4. If the thread being killed is the currently running one,
//     *    trigger a context switch after exiting critical section
//     ***************************************************************/
//    if (threadToKill == CurrentlyRunningThread)
//    {
//        EndCriticalSection(IBit_State);
//        HWREG(NVIC_INT_CTRL) |= NVIC_INT_CTRL_PEND_SV; // PendSV for context switch
//        return NO_ERROR;
//    }
//
//    /***************************************************************
//     * 5. Otherwise, just exit critical section and return
//     ***************************************************************/
////    EndCriticalSection(IBit_State);
//    return NO_ERROR;
//}

sched_ErrCode_t G8RTOS_KillThread(threadID_t threadID)
{
    uint32_t m = StartCriticalSection();

    if (NumberOfThreads <= 1)
    {
        EndCriticalSection(m);
        return CANNOT_KILL_LAST_THREAD;
    }

    tcb_t *threadToKill = NULL;

    for (int i = 0; i < MAX_THREADS; i++)
    {
        if (threadControlBlocks[i].isAlive &&
            threadControlBlocks[i].ThreadID == threadID)
        {
            threadToKill = &threadControlBlocks[i];
            break;
        }
    }

    if (threadToKill == NULL)
    {
        EndCriticalSection(m);
        return THREAD_DOES_NOT_EXIST;
    }

    // Remove from circular linked list
    threadToKill->isAlive = 0;
    threadToKill->previousTCB->nextTCB = threadToKill->nextTCB;
    threadToKill->nextTCB->previousTCB = threadToKill->previousTCB;

    // Nullify stack pointer to mark as free
    threadToKill->StackPointer = 0;

    NumberOfThreads--;

    // If killing current thread, force context switch
    if (threadToKill == CurrentlyRunningThread)
    {
        EndCriticalSection(m);
        HWREG(NVIC_INT_CTRL) |= NVIC_INT_CTRL_PEND_SV;
        return NO_ERROR;
    }

    EndCriticalSection(m);
    return NO_ERROR;
}



// G8RTOS_KillSelf
// Kills currently running thread.
// Return: sched_ErrCode_t
//sched_ErrCode_t G8RTOS_KillSelf() {
//    // your code
//
//    uint32_t IBit_State = StartCriticalSection();
//
//    /***************************************************************
//     * 1. If only one thread, don�t kill it
//     ***************************************************************/
//    if (NumberOfThreads <= 1)
//    {
//        EndCriticalSection(IBit_State);
//        return CANNOT_KILL_LAST_THREAD;
//    }
//
//    /***************************************************************
//     * 2. Mark current thread as dead and remove it from linked list
//     ***************************************************************/
//    CurrentlyRunningThread->isAlive = 0;
//
//    CurrentlyRunningThread->previousTCB->nextTCB = CurrentlyRunningThread->nextTCB;
//    CurrentlyRunningThread->nextTCB->previousTCB = CurrentlyRunningThread->previousTCB;
//
//    NumberOfThreads--;
//
//    /***************************************************************
//     * 3. Exit critical section, then trigger PendSV for context switch
//     ***************************************************************/
//    EndCriticalSection(IBit_State);
//
//    HWREG(NVIC_INT_CTRL) |= NVIC_INT_CTRL_PEND_SV;  // Context switch immediately
//
//    return NO_ERROR;
//}


sched_ErrCode_t G8RTOS_KillSelf() {

    return G8RTOS_KillThread(CurrentlyRunningThread->ThreadID);
}



// G8RTOS_GetThreadID
// Gets current thread ID.
// Return: threadID_t
threadID_t G8RTOS_GetThreadID(void) {
    return CurrentlyRunningThread->ThreadID;        //Returns the thread ID
}

// G8RTOS_GetNumberOfThreads
// Gets number of threads.
// Return: uint32_t
uint32_t G8RTOS_GetNumberOfThreads(void) {
    return NumberOfThreads;         //Returns the number of threads
}
/********************************Public Functions***********************************/



