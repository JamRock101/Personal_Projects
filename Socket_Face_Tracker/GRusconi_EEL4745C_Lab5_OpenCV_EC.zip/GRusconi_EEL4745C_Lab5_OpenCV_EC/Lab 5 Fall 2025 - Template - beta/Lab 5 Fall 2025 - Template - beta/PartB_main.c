#include "G8RTOS/G8RTOS.h"
#include "./MultimodDrivers/multimod.h"
#include "./threads.h"

int main(void)
{
    // 80 MHz system clock
    SysCtlClockSet(SYSCTL_SYSDIV_2_5 | SYSCTL_USE_PLL |
                   SYSCTL_OSC_MAIN | SYSCTL_XTAL_16MHZ);

    ST7789_Init();
    UART_BeagleBone_Init();
    G8RTOS_Init();

    // Init semaphores and FIFO
    G8RTOS_InitSemaphore(&sem_SPIA, 1);
    G8RTOS_InitFIFO(UART_FIFO);

    // Add threads (order matters for priority)
    G8RTOS_AddThread(Idle_Thread,        255, "idle");
    G8RTOS_AddThread(LCD_Draw_Thread,     3,  "lcd_draw");
    G8RTOS_AddThread(UART_Receive_Thread, 4,  "uart_rx");

    // Launch RTOS
    G8RTOS_Launch();
    while (1);
}
