#include "G8RTOS/G8RTOS.h"
#include "./MultimodDrivers/multimod.h"
#include "./threads.h"


int main(void)
{
    // 80 MHz system clock
    SysCtlClockSet(SYSCTL_SYSDIV_2_5 | SYSCTL_USE_PLL |
                   SYSCTL_OSC_MAIN | SYSCTL_XTAL_16MHZ);

    Bluetooth_UART3_Init();
    UART_Init();
//    ST7789_Init();
    G8RTOS_Init();


    // Init semaphores and FIFO
    G8RTOS_InitSemaphore(&sem_UART, 1);
    G8RTOS_InitFIFO(BLUETOOTH_FIFO);

    // Add threads (order matters for priority)
    G8RTOS_AddThread(Idle_Thread,        255, "idle");
    G8RTOS_AddThread(Write_UART0_Thread,     3,  "uart0_display");
    G8RTOS_AddThread(Read_Bluetooth_Thread, 4,  "uart3_rx");

    // Launch RTOS
    G8RTOS_Launch();
    while (1);
}
