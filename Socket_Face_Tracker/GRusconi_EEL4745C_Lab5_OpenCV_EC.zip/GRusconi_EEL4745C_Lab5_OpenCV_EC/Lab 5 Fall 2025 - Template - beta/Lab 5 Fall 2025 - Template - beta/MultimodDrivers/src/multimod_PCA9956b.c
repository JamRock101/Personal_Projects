// multimod_PCA9956b.c
// Date Created: 2023-07-25
// Date Updated: 2025-10-26
// PCA9956B LED driver configuration and helper functions

#include "../multimod_PCA9956b.h"
#include "../multimod_i2c.h"
#include <driverlib/gpio.h>
#include <driverlib/sysctl.h>
#include <stdint.h>
#include <math.h>

/************************************Defines***************************************/
#define PCA9956B_I2C_MOD             1       // Using I2C1
#define PCA9956B_ADDR                0x01    // Default 7-bit I2C address for PCA9956B

// Register map (based on datasheet)
#define PCA9956B_MODE1_REG           0x00
#define PCA9956B_MODE2_REG           0x01
#define PCA9956B_PWMALL_REG          0x25
#define PCA9956B_IREFALL_REG         0x45
#define PCA9956B_GRPPWM_REG          0x08
#define PCA9956B_GRPFREQ_REG         0x09
#define PCA9956B_LEDOUT0_REG         0x02

#define OE_PORT_BASE GPIO_PORTB_BASE
#define OE_PIN       GPIO_PIN_2     // Example output enable pin (edit if different)

/************************************Functions*************************************/

// PCA9956B_Init()
// Initializes the PCA9956B and ensures outputs start disabled
void PCA9956b_Init(void)
{
    I2C_Init(PCA9956B_I2C_MOD);

    // Configure OE pin as output and set HIGH (disable)
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOB);
    while(!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOB));
    GPIOPinTypeGPIOOutput(OE_PORT_BASE, OE_PIN);
    GPIOPinWrite(OE_PORT_BASE, OE_PIN, 0xFF);

    // MODE1: Normal mode, auto-increment enabled
    uint8_t mode1_data[2] = { PCA9956B_MODE1_REG, 0x00 };
    I2C_WriteMultiple(PCA9956B_I2C_MOD, PCA9956B_ADDR, mode1_data, 2);

    // MODE2: Totem pole outputs, group dimming enabled
    uint8_t mode2_data[2] = { PCA9956B_MODE2_REG, 0x04 };
    I2C_WriteMultiple(PCA9956B_I2C_MOD, PCA9956B_ADDR, mode2_data, 2);

    // All outputs off initially
    PCA9956b_SetAllOff();

    // Enable output drivers
    PCA9956b_EnableOutput();
}

// PCA9956b_SetAllMax()
// Sets all LEDs to maximum current and 100% PWM
void PCA9956b_SetAllMax(void)
{
    uint8_t data_PWM[2] = { PCA9956B_PWMALL_REG, 0xFF };
    uint8_t data_IREF[2] = { PCA9956B_IREFALL_REG, 0xFF };

    I2C_WriteMultiple(PCA9956B_I2C_MOD, PCA9956B_ADDR, data_PWM, 2);
    I2C_WriteMultiple(PCA9956B_I2C_MOD, PCA9956B_ADDR, data_IREF, 2);
}

// PCA9956b_SetAllOff()
// Turns all LEDs off by setting PWM = 0
void PCA9956b_SetAllOff(void)
{
    uint8_t data_PWM[2] = { PCA9956B_PWMALL_REG, 0x00 };
    uint8_t data_IREF[2] = { PCA9956B_IREFALL_REG, 0x00 };

    I2C_WriteMultiple(PCA9956B_I2C_MOD, PCA9956B_ADDR, data_PWM, 2);
    I2C_WriteMultiple(PCA9956B_I2C_MOD, PCA9956B_ADDR, data_IREF, 2);
}

// PCA9956b_EnableOutput()
// Drives OE pin low to enable LED outputs
void PCA9956b_EnableOutput(void)
{
    GPIOPinWrite(OE_PORT_BASE, OE_PIN, 0x00);
}

// PCA9956b_DisableOutput()
// Drives OE pin high to disable all LED outputs
void PCA9956b_DisableOutput(void)
{
    GPIOPinWrite(OE_PORT_BASE, OE_PIN, 0xFF);
}

// PCA9956b_GroupSetLED()
// Adjusts the overall LED brightness via Group PWM
void PCA9956b_GroupSetLED(uint8_t PWM)
{
    uint8_t data[2];
    data[0] = PCA9956B_GRPPWM_REG;
    data[1] = PWM;
    I2C_WriteMultiple(PCA9956B_I2C_MOD, PCA9956B_ADDR, data, 2);
}
