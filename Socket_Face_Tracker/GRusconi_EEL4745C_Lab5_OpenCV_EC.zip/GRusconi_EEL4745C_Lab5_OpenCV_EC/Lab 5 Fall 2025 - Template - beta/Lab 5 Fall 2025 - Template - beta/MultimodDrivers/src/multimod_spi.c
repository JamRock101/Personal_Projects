// multimod_spi.c
// Date Created: 2023-07-25
// Date Updated: 2023-07-27
// Defines for SPI functions

/************************************Includes***************************************/

#include "../multimod_spi.h"

#include <driverlib/gpio.h>
#include <driverlib/sysctl.h>
#include <driverlib/pin_map.h>

#include <inc/tm4c123gh6pm.h>
#include <inc/hw_ssi.h>

/************************************Includes***************************************/

/********************************Public Functions***********************************/

// SPI_Init
// Initializes specified SPI module. By default the mode
// is set to communicate with the TFT display.
// Param uint32_t "mod": base address of module
// Return: void
void SPI_Init(uint32_t mod) {


    uint32_t base_addr;
    switch (mod){
        case 0: // for spi_bus_A
            base_addr = SSI0_BASE; //for ssi module 0
            break;

        case 1: // for spi_bus_B
            base_addr = SSI2_BASE; //for ssi module 2
            break;

        default:
            return;
    }


    if (base_addr == SSI0_BASE) { // for spi_bus_A
        SysCtlPeripheralEnable(SYSCTL_PERIPH_SSI0);
        while(!SysCtlPeripheralReady(SYSCTL_PERIPH_SSI0));

        SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);
        while(!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOA));

        GPIOPinConfigure(GPIO_PA2_SSI0CLK);
        GPIOPinConfigure(GPIO_PA4_SSI0RX);
        GPIOPinConfigure(GPIO_PA5_SSI0TX);
        GPIOPinTypeSSI(GPIO_PORTA_BASE, GPIO_PIN_2 | GPIO_PIN_4 | GPIO_PIN_5);
    }

    if (base_addr == SSI2_BASE) { // for spi_bus_B
        SysCtlPeripheralEnable(SYSCTL_PERIPH_SSI2);
        while(!SysCtlPeripheralReady(SYSCTL_PERIPH_SSI2));

        SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOB);
        while(!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOB));

        GPIOPinConfigure(GPIO_PB4_SSI2CLK);
        GPIOPinConfigure(GPIO_PB6_SSI2RX);
        GPIOPinConfigure(GPIO_PB7_SSI2TX);
        GPIOPinTypeSSI(GPIO_PORTB_BASE, GPIO_PIN_4 | GPIO_PIN_6 | GPIO_PIN_7);

    }

    SSIDisable(base_addr);

    SSIConfigSetExpClk(base_addr, SysCtlClockGet(), SSI_FRF_MOTO_MODE_3, SSI_MODE_MASTER, 1000000, 8);        // 8-bit transfers

    SSIEnable(base_addr);

}

// SPI_WriteSingle
// Writes a single byte over the SPI line.
// No need to declare an address as in I2C as
// the code is expected to select the chip prior
// to calling this function.
// Param uint32_t "mod": base address of module
// Param uint8_t "byte": byte to send
// Return: void
void SPI_WriteSingle(uint32_t mod, uint8_t byte) {

    uint32_t base_addr;
    switch (mod){
        case 0: // for spi_bus_A
            base_addr = SSI0_BASE; //for ssi module 0
            break;

        case 1: // for spi_bus_B
            base_addr = SSI2_BASE; //for ssi module 2
            break;

        default:
            return;
    }

    SSIDataPut(base_addr, byte);
    while(SSIBusy(base_addr));
    return;
}

// SPI_ReadSingle
// Reads a single byte from SSI module.
// Param uint32_t "mod": base address of module
// Return: uint8_t
uint8_t SPI_ReadSingle(uint32_t mod) {
    uint32_t result = 0;

    uint32_t base_addr;
    switch (mod){
        case 0: // for spi_bus_A
            base_addr = SSI0_BASE; //for ssi module 0
            break;

        case 1: // for spi_bus_B
            base_addr = SSI2_BASE; //for ssi module 2
            break;

        default:
            return;
    }

    SSIDataPut(base_addr, 0x00);
    while(SSIBusy(base_addr));

    SSIDataGet(base_addr, &result);

    return result;
}

// SPI_WriteMultiple
// Write multiple bytes to a device.
// Param uint32_t "mod": base address of module
// Param uint8_t* "data": pointer to an array of bytes
// Param uint8_t "num_bytes": number of bytes to transmit
// Return: void
void SPI_WriteMultiple(uint32_t mod, uint32_t* data, uint8_t num_bytes) {

    uint32_t base_addr;
    switch (mod){
        case 0: // for spi_bus_A
            base_addr = SSI0_BASE; //for ssi module 0
            break;

        case 1: // for spi_bus_B
            base_addr = SSI2_BASE; //for ssi module 2
            break;

        default:
            return;
    }

    SSIDataPut(base_addr, *data++);
    num_bytes--;
    while(SSIBusy(base_addr));

    while(num_bytes > 0) {
        SSIDataPut(base_addr, *data++);
        num_bytes--;
        while(SSIBusy(base_addr));
    }
}

// SPI_ReadMultiple
// Read multiple bytes from a device.
// Param uint32_t "mod": base address of module
// Param uint8_t* "data": pointer to an array of bytes
// Param uint8_t "num_bytes": number of bytes to read
// Return: void
void SPI_ReadMultiple(uint32_t mod, uint32_t* data, uint8_t num_bytes) {

    uint32_t base_addr;
    switch (mod){
        case 0: // for spi_bus_A
            base_addr = SSI0_BASE; //for ssi module 0
            break;

        case 1: // for spi_bus_B
            base_addr = SSI2_BASE; //for ssi module 2
            break;

        default:
            return;
    }


    SSIDataPut(base_addr, 0x00);
    num_bytes--;
    while(SSIBusy(base_addr));
    SSIDataGet(base_addr, data++);

    while(num_bytes > 0) {
        SSIDataPut(base_addr, 0x00);
        num_bytes--;
        while(SSIBusy(base_addr));
        SSIDataGet(base_addr, data++);
    }

    return;
}

/********************************Public Functions***********************************/

