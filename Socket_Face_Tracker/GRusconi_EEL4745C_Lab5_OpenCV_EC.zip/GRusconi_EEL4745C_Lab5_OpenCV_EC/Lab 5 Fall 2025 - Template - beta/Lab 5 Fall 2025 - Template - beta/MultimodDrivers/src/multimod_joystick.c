// multimod_joystick.c
// Date Created: 2023-07-25
// Date Updated: 2023-07-27
// Defines for joystick functions

/************************************Includes***************************************/

#include "../multimod_joystick.h"

#include <driverlib/gpio.h>
#include <driverlib/sysctl.h>
#include <driverlib/pin_map.h>
#include <driverlib/adc.h>
#include <driverlib/interrupt.h>

#include <inc/tm4c123gh6pm.h>
#include <inc/hw_types.h>
#include <inc/hw_memmap.h>
#include <inc/hw_i2c.h>
#include <inc/hw_gpio.h>

/************************************Includes***************************************/
#define JOY_X_PIN GPIO_PIN_3
#define JOY_Y_PIN GPIO_PIN_2
#define JOY_BUTTON_PIN GPIO_PIN_2
#define JOY_BUTTON_PORT_BASE GPIO_PORTD_BASE
#define Joy_X_pos 3
#define Joy_Y_pos 2


/********************************Public Functions***********************************/

// JOYSTICK_Init
// Initializes ports & adc module for joystick
// Return: void
void JOYSTICK_Init(void) {
    // your code

    //initialise port D for joystick switch as an input
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOD);
    while(!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOD));

    GPIOPinTypeGPIOInput(JOY_BUTTON_PORT_BASE, JOY_BUTTON_PIN);
    GPIOPadConfigSet(JOY_BUTTON_PORT_BASE, JOY_BUTTON_PIN, GPIO_STRENGTH_2MA, GPIO_PIN_TYPE_STD_WPU);

    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOE);
    while(!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOE));  // wait here




    //initialise port E ADC for X and Y axis
    // Enable the ADC0 module.
    //
    SysCtlPeripheralEnable(SYSCTL_PERIPH_ADC0);
    //
    // Wait for the ADC0 module to be ready.
    //
    while(!SysCtlPeripheralReady(SYSCTL_PERIPH_ADC0))
    {
    }

    SYSCTL_RCGCADC_R |= 0x01;
    ADC0_PC_R = 0x07;


    //configure PE3 and PE2 as adc inputs
    GPIOE_Alternate_Analog_Config(JOY_X_PIN); //PE3
    GPIOE_Alternate_Analog_Config(JOY_Y_PIN); //PE3
}


void GPIOE_Alternate_Analog_Config(uint8_t GPIO_PIN)
{
        /* Initialize PE3 for AIN0 input  */
    GPIO_PORTE_DIR_R &= ~(GPIO_PIN); // make PD3 input
    GPIO_PORTE_AFSEL_R |= (GPIO_PIN); // enable alternate function on
    GPIO_PORTE_DEN_R &= ~(GPIO_PIN); // disable digital I/O on
    GPIO_PORTE_AMSEL_R |= (GPIO_PIN); // enable analog functionality on
}


//uint16_t ADC0_GPIOE_pinspecific_read(uint8_t GPIO_PIN){
//
//    uint16_t adcResult;
//
//
//
//    if ((GPIO_PIN) == JOY_X_PIN){
//
//        ADC0_ACTSS_R &= ~(0x08);           /* Disable SS3 before configuration */
//        ADC0_EMUX_R &= ~0xF000;          /* Software trigger conversion */
//        ADC0_SSMUX3_R = 0x00;            /* Get input from channel 0 */
//        ADC0_SSCTL3_R |= 0x06;               /* Take one sample */
//        ADC0_ACTSS_R |= (0x08);            /* Enable ADC0 Sequencer 3 */
//
//        ADC0_PSSI_R |= (0x08);                /* Start ADC conversion for Sample Sequencer 3 */
//        while((ADC0_RIS_R & 8) == 0) ;  /* Wait till ADC conversion is completed */
//        adcResult = ADC0_SSFIFO3_R & 0xFFF;         /* Retrieve the conversion result from the SS3 FIFO */
//        ADC0_ISC_R = (0x08);            /* Clear the interrupt flag for Sample Sequencer 3 */
//    }
//
//    if ((GPIO_PIN) == JOY_Y_PIN){
//
//        ADC0_ACTSS_R &= ~(0x04);           /* Disable SS2 before configuration */
//        ADC0_EMUX_R &= ~0xF000;          /* Software trigger conversion */
//        ADC0_SSMUX2_R = 0x00;            /* Get input from channel 0 */
//        ADC0_SSCTL2_R |= 0x06;               /* Take one sample */
//        ADC0_ACTSS_R |= (0x04);            /* Enable ADC0 Sequencer 2 */
//
//        ADC0_PSSI_R |= (0x04);                /* Start ADC conversion for Sample Sequencer 2 */
//        while((ADC0_RIS_R & 4) == 0) ;  /* Wait till ADC conversion is completed */
//        adcResult = ADC0_SSFIFO2_R & 0xFFF;         /* Retrieve the conversion result from the SS2 FIFO */
//        ADC0_ISC_R = (0x04);
//
//    }
//
//                      /* Clear the interrupt flag for Sample Sequencer 3 */
//
//    return (uint16_t) adcResult;
//}

uint16_t ADC0_GPIOE_pinspecific_read(uint8_t GPIO_PIN){

    uint16_t adcResult;



    if ((GPIO_PIN) == JOY_X_PIN){

        ADC0_ACTSS_R &= ~(0x08);           /* Disable SS3 before configuration */
        ADC0_EMUX_R &= ~0xF000;          /* Software trigger conversion */
        ADC0_SSMUX3_R = 0x00;            /* Get input from channel 0 (AIN0) = PE3 */
        ADC0_SSCTL3_R |= 0x06;               /* Take one sample */
        ADC0_ACTSS_R |= (0x08);            /* Enable ADC0 Sequencer 3 */

        ADC0_PSSI_R |= (0x08);                /* Start ADC conversion for Sample Sequencer 3 */
        while((ADC0_RIS_R & 8) == 0) ;  /* Wait till ADC conversion is completed */
        adcResult = ADC0_SSFIFO3_R & 0xFFF;         /* Retrieve the conversion result from the SS3 FIFO */
        ADC0_ISC_R = (0x08);            /* Clear the interrupt flag for Sample Sequencer 3 */
    }

    if ((GPIO_PIN) == JOY_Y_PIN){

        ADC0_ACTSS_R &= ~(0x08);           /* Disable SS3 before configuration */
        ADC0_EMUX_R &= ~0xF000;          /* Software trigger conversion */
        ADC0_SSMUX3_R = 0x01;            /* Get input from channel 1 (AIN1) = PE2 */
        ADC0_SSCTL3_R |= 0x06;               /* Take one sample */
        ADC0_ACTSS_R |= (0x08);            /* Enable ADC0 Sequencer 3 */

        ADC0_PSSI_R |= (0x08);                /* Start ADC conversion for Sample Sequencer 3 */
        while((ADC0_RIS_R & 8) == 0) ;  /* Wait till ADC conversion is completed */
        adcResult = ADC0_SSFIFO3_R & 0xFFF;         /* Retrieve the conversion result from the SS3 FIFO */
        ADC0_ISC_R = (0x08);            /* Clear the interrupt flag for Sample Sequencer 3 */

    }

                      /* Clear the interrupt flag for Sample Sequencer 3 */

    return (uint16_t) adcResult;
}

// JOYSTICK_IntEnable
// Enables interrupts
// Return: void
void JOYSTICK_IntEnable(void)
{
    /************************************************************
     * 1. Configure and enable interrupt for joystick button (PD2)
     ************************************************************/
    GPIOIntDisable(JOY_BUTTON_PORT_BASE, JOY_BUTTON_PIN);
    GPIOIntClear(JOY_BUTTON_PORT_BASE, JOY_BUTTON_PIN);
    GPIOIntTypeSet(JOY_BUTTON_PORT_BASE, JOY_BUTTON_PIN, GPIO_FALLING_EDGE);
    GPIOIntEnable(JOY_BUTTON_PORT_BASE, JOY_BUTTON_PIN);

    // Enable Port D interrupts in NVIC
    IntEnable(INT_GPIOD);

    /************************************************************
     * 2. Configure and enable interrupts for joystick analog pins
     *    (PE2 and PE3)
     *    These can be used to trigger ADC sampling or movement
     *    detection logic in GPIOE_Handler().
     ************************************************************/

}

// JOYSTICK_GetPress
// Gets button reading
// Return: bool
uint8_t JOYSTICK_GetPress() {
    // Joystick press switch is on PD2 (active low)
    uint8_t value = GPIOPinRead(JOY_BUTTON_PORT_BASE, JOY_BUTTON_PIN);

    // Return 1 if pressed (low = pressed)
    return (value == 0) ? 1 : 0;
}

// JOYSTICK_GetX
// Gets X adc reading from joystick
// Return: uint16_t

uint16_t JOYSTICK_GetX() {

    // Joystick_X = PE3 = AIN0 (ADC signal)
    uint16_t adcValue_X;

    adcValue_X = ADC0_GPIOE_pinspecific_read(GPIO_PIN_3);

    return (uint16_t)adcValue_X;
}

// JOYSTICK_GetY
// Gets Y adc reading from joystick
// Return: uint16_t
uint16_t JOYSTICK_GetY() {

    // Joystick_Y = PE2 = AIN1 (ADC signal)
    uint16_t adcValue_Y;

    adcValue_Y = ADC0_GPIOE_pinspecific_read(GPIO_PIN_2);

    return (uint16_t)adcValue_Y;
}


// JOYSTICK_GetXY
// Gets X and Y adc readings
// Return: uint32_t, 16-bit packed, upper 16-bit is X and lower 16-bit is Y.
uint32_t JOYSTICK_GetXY() {
    // your code

    uint16_t UpperX = JOYSTICK_GetX();
    uint16_t LowerY = JOYSTICK_GetY();

    uint32_t packedXY = ((uint32_t)UpperX << 16) | (uint32_t)LowerY;

    return (packedXY);
}

/********************************Public Functions***********************************/

