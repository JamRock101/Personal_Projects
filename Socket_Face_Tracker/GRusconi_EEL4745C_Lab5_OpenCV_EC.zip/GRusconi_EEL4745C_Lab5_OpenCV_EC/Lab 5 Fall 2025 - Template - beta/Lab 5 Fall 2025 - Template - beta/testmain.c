#include <stdint.h>
#include <stdbool.h>
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"
#include "driverlib/uart.h"
#include "driverlib/pin_map.h"
//#include "utils/uartstdio.h"

/*********************************************************************
 *  UART4_Init()
 *  Configures UART4 on PC4 (RX) / PC5 (TX) at 115200 baud
 *********************************************************************/
void UART4_Init(void)
{
    // Enable port C
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOC);
    // Enable UART4 module
    SysCtlPeripheralEnable(SYSCTL_PERIPH_UART4);

    // Configure UART0 pins on port A

    GPIOPinConfigure(GPIO_PC4_U4RX);
    GPIOPinConfigure(GPIO_PC5_U4TX);
    GPIOPinTypeUART(GPIO_PORTC_BASE, GPIO_PIN_4 | GPIO_PIN_5);

    UARTConfigSetExpClk(UART4_BASE, SysCtlClockGet(), 115200, (UART_CONFIG_WLEN_8 | UART_CONFIG_STOP_ONE | UART_CONFIG_PAR_NONE));

    UARTStdioConfig(0, 115200, SysCtlClockGet());

}

/*********************************************************************
 *  UART0_Init()
 *  Initializes USB serial (debug) console at 115200 baud
 *********************************************************************/
void UART0_Init(void)
{
    // Enable port A
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);
    // Enable UART0 module
    SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);

    // Configure UART0 pins on port A

    GPIOPinConfigure(GPIO_PA0_U0RX);
    GPIOPinConfigure(GPIO_PA1_U0TX);
    GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);

    UARTFIFODisable(UART0_BASE);

    // Set UART clock source
    UARTClockSourceSet(UART0_BASE, UART_CLOCK_SYSTEM);
    // Configure UART baud rate

    UARTStdioConfig(0, 115200, SysCtlClockGet());

}
/*********************************************************************
 *  main()
 *  Receives text from BBB on UART4 and prints to UART0 terminal
 *********************************************************************/
int main(void)
{
    // 80 MHz system clock
    SysCtlClockSet(SYSCTL_SYSDIV_2_5 | SYSCTL_USE_PLL |
                   SYSCTL_OSC_MAIN | SYSCTL_XTAL_16MHZ);

    UART4_Init();   // BBB UART link
//    UART0_Init();   // USB terminal

//    UARTprintf("\n=== UART4 Hello World Receiver ===\n");

//    while (1)
//    {
//        if (UARTCharsAvail(UART4_BASE))
//        {
//            char c = UARTCharGet(UART4_BASE);   // get byte from BBB
//            UARTCharPut(UART0_BASE, c);         // print to USB terminal
//        }
//    }

    while (1)
    {
        char test_in = UARTCharGet(UART4_BASE);   // get byte from BBB
      //  asm("nop");
    }
}
