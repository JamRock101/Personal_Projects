#include "G8RTOS/G8RTOS.h"
#include "./MultimodDrivers/multimod.h"
#include "./threads.h"

int main(void)
{
    // 80 MHz system clock
    SysCtlClockSet(SYSCTL_SYSDIV_2_5 | SYSCTL_USE_PLL |
                   SYSCTL_OSC_MAIN | SYSCTL_XTAL_16MHZ);

    ST7789_Init();
    ST7789_Fill(0x0000); // black
    UART_BeagleBone_Init();
    G8RTOS_Init();

    // Init semaphores and FIFO
    G8RTOS_InitSemaphore(&sem_SPIA, 1);
    G8RTOS_InitFIFO(UART_FIFO_X);
    G8RTOS_InitFIFO(UART_FIFO_Y);

    // Add threads (order matters for priority)
    G8RTOS_AddThread(Idle_Thread,        255, "idle");
    G8RTOS_AddThread(LCD_Draw_Thread_EC,     3,  "lcd_draw_ec");
    G8RTOS_AddThread(UART_Receive_Thread_EC, 2,  "uart_rx_ec");

    // Launch RTOS
    G8RTOS_Launch();
    while (1);
}
