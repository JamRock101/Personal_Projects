#include "./threads.h"
#include "./MultimodDrivers/multimod.h"
#include "./G8RTOS/G8RTOS_Structures.h"

#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>

/********************************** Semaphores **********************************/
semaphore_t sem_SPIA = 1;
semaphore_t sem_UART = 1;

/********************************** Defines **********************************/
#define PACKET_SIZE     7   // x,y,w,h,r,g,b
#define TIMEOUT_MS      100
#define CLEAR_CMD_META  0xFFFFFFFF

#define LCD_BLACK       0x0000
#define MAX_BT_MSG_LEN 8

#define EC_BLUE  0x001F
#define EC_WIDTH  40
#define EC_HEIGHT 70

/********************************** Helpers **********************************/
static inline uint16_t RGB888_to_565(uint8_t r, uint8_t g, uint8_t b)
{
    return (uint16_t)(((r & 0xF8) << 8) |
                      ((g & 0xFC) << 3) |
                      ((b & 0xF8) >> 3));
}

static inline uint32_t PackMeta(uint8_t x, uint8_t y, uint8_t w, uint8_t h)
{
    return ((uint32_t)x << 24) | ((uint32_t)y << 16) |
           ((uint32_t)w << 8)  | ((uint32_t)h);
}

/********************************** Idle Thread **********************************/
void Idle_Thread(void)
{
    while (1)
    {

    }
}

/********************************** UART Receive Thread **********************************/
void UART_Receive_Thread(void)
{
    uint8_t pkt[PACKET_SIZE];
    uint8_t idx = 0;
    uint32_t idle_ticks = 0;

    while (1)
    {
        int ch = UARTCharGetNonBlocking(UART4_BASE);

        if (ch >= 0)
        {
            pkt[idx++] = (uint8_t)ch;
            idle_ticks = 0;

            // Packet complete
            if (idx >= PACKET_SIZE)
            {
                uint8_t x = pkt[0];
                uint8_t y = pkt[1];
                uint8_t w = pkt[2];
                uint8_t h = pkt[3];
                uint8_t r = pkt[4];
                uint8_t g = pkt[5];
                uint8_t b = pkt[6];

                uint16_t color = RGB888_to_565(r, g, b);
                uint32_t meta  = PackMeta(x, y, w, h);

                G8RTOS_WriteFIFO(UART_FIFO, meta);
                G8RTOS_WriteFIFO(UART_FIFO, color);

                idx = 0;
            }
        }
        else
        {
            // No data — sleep and check timeout
            G8RTOS_Sleep(1);
            idle_ticks++;

            if (idle_ticks >= TIMEOUT_MS)
            {
                idle_ticks = 0;
                // Send keepalive clear (prevents LCD thread from stalling)
                G8RTOS_WriteFIFO(UART_FIFO, CLEAR_CMD_META);
                G8RTOS_WriteFIFO(UART_FIFO, 0);
                idx = 0;
            }
        }
    }
}

/********************************** LCD Draw Thread **********************************/
void LCD_Draw_Thread(void)
{
    // Start with a clean screen
    G8RTOS_WaitSemaphore(&sem_SPIA);
    ST7789_Fill(LCD_BLACK);
    G8RTOS_SignalSemaphore(&sem_SPIA);

    while (1)
    {
        // Each rectangle = 2 FIFO reads (meta + color)
        uint32_t meta  = G8RTOS_ReadFIFO(UART_FIFO);
        uint32_t color = G8RTOS_ReadFIFO(UART_FIFO);

        if (meta == CLEAR_CMD_META)
        {
            G8RTOS_WaitSemaphore(&sem_SPIA);
            ST7789_Fill(LCD_BLACK);
            G8RTOS_SignalSemaphore(&sem_SPIA);
            continue;
        }

        // Unpack bytes
        int x = (meta >> 24) & 0xFF;
        int y = (meta >> 16) & 0xFF;
        int w = (meta >> 8)  & 0xFF;
        int h = (meta >> 0)  & 0xFF;

        // Validate geometry
        if (w <= 0 || h <= 0 || x >= X_MAX || y >= Y_MAX)
            continue;
        if (x + w > X_MAX) w = X_MAX - x;
        if (y + h > Y_MAX) h = Y_MAX - y;

        // Clear the screen before drawing the new rectangle
        G8RTOS_WaitSemaphore(&sem_SPIA);
        ST7789_Fill(LCD_BLACK);  // ensures only one shape on screen
        ST7789_DrawRectangle(x, y, w, h, (uint16_t)color);
        G8RTOS_SignalSemaphore(&sem_SPIA);

        // Short sleep gives display time to refresh
        G8RTOS_Sleep(10);
    }
}





void Read_Bluetooth_Thread(void)
{
    char msg[64];
    uint32_t idx = 0;

    while (1)
    {
        int ch = UARTCharGetNonBlocking(UART3_BASE);

        if (ch == -1)
        {
            // No data: let CPU rest
            G8RTOS_Sleep(1);
            continue;
        }

        char c = (char)ch;

        if (c == '\r')
            continue;

        // Newline = message complete
        if (c == '\n')
        {
            msg[idx] = '\0';

            // Send to FIFO char-by-char including '\0'
            for (uint32_t i = 0; i <= idx; i++)
                G8RTOS_WriteFIFO(BLUETOOTH_FIFO, msg[i]);

            idx = 0;
        }
        else
        {
            if (idx < sizeof(msg) - 1)
                msg[idx++] = c;
        }

        G8RTOS_Sleep(50);

    }
}

/************************************************************
 * Write_UART0_Thread
 *  - Reads characters from FIFO
 *  - Outputs them on UART0 terminal
 ************************************************************/
void Write_UART0_Thread(void)
{
    while (1)
    {
        char c = (char)G8RTOS_ReadFIFO(BLUETOOTH_FIFO);

        G8RTOS_WaitSemaphore(&sem_UART);
        UARTCharPut(UART0_BASE, c);
        G8RTOS_SignalSemaphore(&sem_UART);
        G8RTOS_Sleep(50);

    }
}


void LCD_Draw_Thread_EC(void)
{
    int old_x = -1;
    int old_y = -1;
    bool showing_box = false;   // tracks whether a rectangle is currently displayed

    while (1)
    {
        uint8_t x = (uint8_t)G8RTOS_ReadFIFO(UART_FIFO_X);
        uint8_t y = (uint8_t)G8RTOS_ReadFIFO(UART_FIFO_Y);

        // Condition: no face detected (PC sends 0,0)
        if (x == 0 && y == 0)
        {
            if (showing_box)
            {
                // erase old rectangle ONCE
                G8RTOS_WaitSemaphore(&sem_SPIA);
                ST7789_DrawRectangle(old_x, old_y, EC_WIDTH, EC_HEIGHT, 0x0000);
                G8RTOS_SignalSemaphore(&sem_SPIA);

                showing_box = false;    // stop drawing until new positions arrive
            }

            // Skip drawing entirely
            G8RTOS_Sleep(1);
            continue;
        }

        // Clip boundaries
        int rect_x = x;
        int rect_y = y;
        int rect_w = EC_WIDTH;
        int rect_h = EC_HEIGHT;

        if (rect_x + rect_w > X_MAX) rect_x = X_MAX - rect_w;
        if (rect_y + rect_h > Y_MAX) rect_y = Y_MAX - rect_h;

        G8RTOS_WaitSemaphore(&sem_SPIA);

        // If rectangle was already on screen, erase old one first
        if (showing_box)
        {
            ST7789_DrawRectangle(old_x, old_y, rect_w, rect_h, 0x0000);
        }

        // Draw new rectangle
        ST7789_DrawRectangle(rect_x, rect_y, rect_w, rect_h, EC_BLUE);

        G8RTOS_SignalSemaphore(&sem_SPIA);

        // Update state
        old_x = rect_x;
        old_y = rect_y;
        showing_box = true;

        G8RTOS_Sleep(1);
    }
}

void UART_Receive_Thread_EC(void)
{
    uint8_t byte;
    bool expectX = true;  // toggle: true = next byte is X, false = Y

    while (1)
    {
        // Blocking read from UART4 (face data from BBB)
        byte = (uint8_t)UARTCharGet(UART4_BASE);  // blocking, but thread-preempti

        if (expectX)
        {
            G8RTOS_WriteFIFO(UART_FIFO_X, byte);
            expectX = false;
        }
        else
        {
            G8RTOS_WriteFIFO(UART_FIFO_Y, byte);
            expectX = true;
        }

        G8RTOS_Sleep(5);
    }
}

