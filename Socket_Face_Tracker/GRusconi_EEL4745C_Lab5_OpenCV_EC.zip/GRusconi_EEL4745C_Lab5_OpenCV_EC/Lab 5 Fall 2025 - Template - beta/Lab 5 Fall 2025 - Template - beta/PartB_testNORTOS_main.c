#include "G8RTOS/G8RTOS.h"
#include "./MultimodDrivers/multimod.h"

#include "./threads.h"



/*********************************************************************
 * main()
 * Polls UART4 for data and draws rectangles on LCD
 *********************************************************************/
int main(void)
{
    uint8_t x, y, w, h, r, g, b;
    uint8_t values[7];

    SysCtlClockSet(SYSCTL_SYSDIV_2_5 | SYSCTL_USE_PLL |
                   SYSCTL_OSC_MAIN | SYSCTL_XTAL_16MHZ);

    ST7789_Init();
    UART_BeagleBone_Init();
//    UART_Init();

//    UARTprintf("\n=== BBB → Tiva UART Binary Demo (No RTOS) ===\n");

    while (1)
    {
        // Wait until 7 bytes have been received
        for (int i = 0; i < 7; i++)
        {
            values[i] = UARTCharGet(UART4_BASE); // blocking receive
        }

        // Assign the values
        x = values[0];
        y = values[1];
        w = values[2];
        h = values[3];
        r = values[4];
        g = values[5];
        b = values[6];

        UARTCharPut(UART0_BASE, x);
        UARTCharPut(UART0_BASE, y);
        UARTCharPut(UART0_BASE, w);
        UARTCharPut(UART0_BASE, h);
        UARTCharPut(UART0_BASE, r);
        UARTCharPut(UART0_BASE, g);
        UARTCharPut(UART0_BASE, b);

        // Convert RGB888 to RGB565
        uint16_t color = ((r & 0xF8) << 8) |((g & 0xFC) << 3) | (b >> 3);

//        UARTprintf("Recv: X=%3d Y=%3d W=%3d H=%3d R=%3d G=%3d B=%3d\n", x, y, w, h, r, g, b);

        // Clear screen and draw rectangle
        ST7789_Fill(0x0000);
        ST7789_DrawRectangle(x, y, w, h, color);

        // Small delay (~0.5 s)
        SysCtlDelay(SysCtlClockGet() / 6);
    }
}
