import socket
import time
import pygame

# ---------------------------------------
# INITIALIZE AUDIO
# ---------------------------------------
pygame.mixer.init()

# ---------------------------------------
# FULL PATHS TO COMMAND AUDIO FILES
# ---------------------------------------
CMD_AUDIO_PATHS = {
    0: r"C:\Users\monch\Desktop\Semester Fall 2025\EEL4745C\Final_Project\python_scripts\command_audios\bop_it_cmd.mp3",
    1: r"C:\Users\monch\Desktop\Semester Fall 2025\EEL4745C\Final_Project\python_scripts\command_audios\flick_up_cmd.mp3",
    2: r"C:\Users\monch\Desktop\Semester Fall 2025\EEL4745C\Final_Project\python_scripts\command_audios\flick_left_cmd.mp3",
    3: r"C:\Users\monch\Desktop\Semester Fall 2025\EEL4745C\Final_Project\python_scripts\command_audios\flick_right_cmd.mp3",
    4: r"C:\Users\monch\Desktop\Semester Fall 2025\EEL4745C\Final_Project\python_scripts\command_audios\flick_down_cmd.mp3",
    5: r"C:\Users\monch\Desktop\Semester Fall 2025\EEL4745C\Final_Project\python_scripts\command_audios\shake_it_cmd.mp3",

    # LOOPING COMMAND
    7: r"C:\Users\monch\Desktop\Semester Fall 2025\EEL4745C\Final_Project\python_scripts\command_audios\gta4_loading.mp3",

    # GAME OVER CMD
    8: r"C:\Users\monch\Desktop\Semester Fall 2025\EEL4745C\Final_Project\python_scripts\command_audios\Game Over Yeah! 2nd Version.mp3",
}

# ---------------------------------------
# BBB CONNECTION SETTINGS
# ---------------------------------------
BBB_IP = "192.168.7.2"
BBB_PORT = 23456

current_looping = False  # tracks whether CMD 7 is currently looping


def play_command_sound(cmd):
    global current_looping

    if cmd not in CMD_AUDIO_PATHS:
        print(f"[WARN] Unknown command {cmd}")
        return

    sound_file = CMD_AUDIO_PATHS[cmd]
    print(f"[PLAY] Command {cmd} → {sound_file}")

    # Stop currently playing audio if looping
    pygame.mixer.music.stop()
    current_looping = False

    if cmd == 7:
        # LOOP FOREVER UNTIL INTERRUPTED
        pygame.mixer.music.load(sound_file)
        pygame.mixer.music.play(loops=-1)
        current_looping = True
        print("[INFO] Looping GTA IV loading theme...")
    else:
        # PLAY ONCE
        pygame.mixer.music.load(sound_file)
        pygame.mixer.music.play(loops=0)
        print("[INFO] Playing once.")


# ---------------------------------------
# MAIN PROGRAM LOOP
# ---------------------------------------
sock = None

while True:
    try:
        if sock is None:
            print(f"[INFO] Connecting to BBB at {BBB_IP}:{BBB_PORT} ...")
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.connect((BBB_IP, BBB_PORT))
            print("[INFO] Connected!")

        data = sock.recv(1)
        if not data:
            print("[WARN] No data. Reconnecting...")
            pygame.mixer.music.stop()
            sock.close()
            sock = None
            continue

        cmd = data[0]
        print(f"[RX] Received command {cmd}")

        play_command_sound(cmd)

    except Exception as e:
        print("[ERROR] Lost connection:", e)
        pygame.mixer.music.stop()
        try:
            if sock:
                sock.close()
        except:
            pass

        sock = None
        time.sleep(1)
