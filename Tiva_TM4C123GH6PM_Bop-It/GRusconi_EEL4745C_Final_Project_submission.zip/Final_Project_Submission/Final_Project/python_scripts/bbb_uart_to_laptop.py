#!/usr/bin/env python3
import serial
import socket
import time
import sys

# -----------------------------
# CONFIGURATION
# -----------------------------
UART_PORT = "/dev/ttyS4"   # UART4 (BBB: P9.11 RX, P9.13 TX)
BAUD = 115200

SERVER_IP = "0.0.0.0"      # Listen on all interfaces
SERVER_PORT = 23456        # Laptop connects to this port

# -----------------------------
# SETUP UART
# -----------------------------
try:
    ser = serial.Serial(UART_PORT, BAUD, timeout=1)
    print(f"[INFO] UART open on {UART_PORT} @ {BAUD}")
except Exception as e:
    print(f"[ERROR] Could not open UART: {e}")
    sys.exit(1)

# -----------------------------
# SETUP TCP SERVER
# -----------------------------
server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
server.bind((SERVER_IP, SERVER_PORT))
server.listen(1)

print(f"[INFO] Waiting for laptop connection on port {SERVER_PORT}...")
conn, addr = server.accept()
print(f"[INFO] Laptop connected: {addr}")

# -----------------------------
# MAIN LOOP
# -----------------------------
while True:
    try:
        if ser.in_waiting > 0:
            cmd_byte = ser.read(1)

            if not cmd_byte:
                continue

            cmd_value = cmd_byte[0]
            print(f"[UART RX] Command = {cmd_value}")

            try:
                conn.sendall(cmd_byte)
            except:
                print("[WARN] Laptop disconnected. Waiting for reconnect...")
                conn, addr = server.accept()
                print(f"[INFO] Reconnected: {addr}")

        time.sleep(0.01)

    except KeyboardInterrupt:
        break

# -----------------------------
# CLEANUP
# -----------------------------
ser.close()
conn.close()
server.close()
print("[INFO] BBB bridge closed.")
