/******************************************************
 * Bop-It Game Threads (NO SPIN VERSION, SPRITES)
 * Giorgio Rusconi
 *
 * Inputs:
 *   SW1     -> Bop-It
 *   SW2     -> Start/Retry
 *   Joystick flicks
 *   BMI160 Accelerometer Y -> Shake-It
 *
 * Threads:
 *   BopIt_Thread           (main FSM)
 *   Read_Buttons_Thread    (SW1/SW2)
 *   Read_Joystick_Thread   (flicks)
 *   Read_Accel_Thread      (shake)
 *   GPIOE_Handler          (PCA9555 INT)
 ******************************************************/

#include "./threads.h"
#include "./MultimodDrivers/multimod.h"
#include "./MultimodDrivers/multimod_BMI160.h"

#include <stdlib.h>
#include <stdbool.h>
#include <stdio.h>

/************ Colors (LCD inverted) *************/
/* These are the colors you were using previously */
#define INV_C_BLACK   0xFFFF
#define INV_C_WHITE   0x0000
#define INV_C_GREEN   0xF81F
#define INV_C_YELLOW  0x001F
#define INV_C_RED     0x07FF

/************ Semaphores *************/
semaphore_t sem_SPIA;
semaphore_t sem_UART;
semaphore_t sem_I2CA;
semaphore_t sem_PCA9555_Debounce;

/******************************************************
 * GAME ENUMS (SPIN REMOVED)
 ******************************************************/
typedef enum {
    CMD_BOP = 0,
    CMD_UP,
    CMD_LEFT,
    CMD_RIGHT,
    CMD_DOWN,
    CMD_SHAKE,
    CMD_COUNT
} BopCommand_t;

typedef enum {
    ACT_NONE = 0,
    ACT_BOP,
    ACT_UP,
    ACT_LEFT,
    ACT_RIGHT,
    ACT_DOWN,
    ACT_SHAKE
} PlayerAction_t;

/************ Command Text *************/
static const char *cmdText[CMD_COUNT] = {
    "Bop-It!",
    "Flick UP!",
    "Flick LEFT!",
    "Flick RIGHT!",
    "Flick DOWN!",
    "Shake-It!"
};

/******************************************************
 * ACTION FIFO (non-blocking)
 ******************************************************/
#define ACTION_FIFO_SIZE 16
static volatile PlayerAction_t actionFifo[ACTION_FIFO_SIZE];
static volatile int head = 0;
static volatile int tail = 0;
static volatile int count = 0;
static semaphore_t sem_Fifo;

static void ActionFifo_Init(void)
{
    head = tail = count = 0;
    G8RTOS_InitSemaphore(&sem_Fifo, 1);
}

static void ActionFifo_Clear(void)
{
    G8RTOS_WaitSemaphore(&sem_Fifo);
    head = tail = count = 0;
    G8RTOS_SignalSemaphore(&sem_Fifo);
}

static void ActionFifo_Push(PlayerAction_t a)
{
    G8RTOS_WaitSemaphore(&sem_Fifo);

    if (count < ACTION_FIFO_SIZE)
    {
        actionFifo[tail] = a;
        tail = (tail + 1) % ACTION_FIFO_SIZE;
        count++;
    }

    G8RTOS_SignalSemaphore(&sem_Fifo);
}

static PlayerAction_t ActionFifo_Pop(void)
{
    PlayerAction_t a = ACT_NONE;

    G8RTOS_WaitSemaphore(&sem_Fifo);
    if (count > 0)
    {
        a = actionFifo[head];
        head = (head + 1) % ACTION_FIFO_SIZE;
        count--;
    }
    G8RTOS_SignalSemaphore(&sem_Fifo);

    return a;
}

/******************************************************
 * Global Start Flag (SW2)
 ******************************************************/
static volatile bool g_sw2_event = false;

/******************************************************
 * Idle Thread
 ******************************************************/
void Idle_Thread(void)
{
    while (1);
}

/******************************************************
 * Sprite Helpers
 ******************************************************/

/* Simple “Bop-It” style logo sprite */
static void DrawBopItLogoSprite(int x, int y)
{
    // Main capsule body
    ST7789_DrawRectangle(x,     y + 10, 120, 40, INV_C_GREEN);
    ST7789_DrawRectangle(x + 4, y + 14, 112, 32, INV_C_BLACK);

    // Left “pod”
    ST7789_DrawRectangle(x - 10,     y + 18, 16, 16, INV_C_YELLOW);
    // Right “pod”
    ST7789_DrawRectangle(x + 120 - 2, y + 18, 16, 16, INV_C_RED);

    // Title text inside capsule
    ST7789_DrawStringStatic("BOP-IT!", INV_C_WHITE, x + 22, y + 24);
}

/* Retro “GAME OVER” style sprite */
static void DrawRetroGameOverSprite(int x, int y)
{
    // Outer frame
    ST7789_DrawRectangle(x,     y,     120, 32, INV_C_BLACK);
    // Inner fill
    ST7789_DrawRectangle(x + 2, y + 2, 116, 28, INV_C_RED);

    // Retro text
    ST7789_DrawStringStatic("GAME OVER", INV_C_WHITE, x + 12, y + 10);
}

static void WaitForSW2Press(void)
{
    /**************************************************
     * 1) Clear any stale SW2 events
     **************************************************/
    g_sw2_event = false;

    /**************************************************
     * 2) Make sure SW2 is currently released
     *    (so we don't treat a held button as a new press)
     **************************************************/
    while (1)
    {
        G8RTOS_WaitSemaphore(&sem_I2CA);
        uint8_t b = MultimodButtons_Get();
        G8RTOS_SignalSemaphore(&sem_I2CA);

        bool sw2 = !(b & 0x04);   // active low
        if (!sw2)
            break;                // fully released

        G8RTOS_Sleep(20);
    }

    /**************************************************
     * 3) Now wait for a NEW SW2 press
     *    (button thread sets g_sw2_event on rising edge)
     **************************************************/
    while (!g_sw2_event)
    {
        G8RTOS_Sleep(10);
    }

    // consume that event
    g_sw2_event = false;

    /**************************************************
     * 4) Debounce: wait for SW2 to be released again
     **************************************************/
    while (1)
    {
        G8RTOS_WaitSemaphore(&sem_I2CA);
        uint8_t b = MultimodButtons_Get();
        G8RTOS_SignalSemaphore(&sem_I2CA);

        bool sw2 = !(b & 0x04);
        if (!sw2)
            break;

        G8RTOS_Sleep(20);
    }
}

/******************************************************
 * Display Helpers (using sprites)
 ******************************************************/
static void DrawWelcome(void)
{

    // Send "main menu music" command = 7
    UARTCharPutNonBlocking(UART4_BASE, 7);
    G8RTOS_WaitSemaphore(&sem_SPIA);
    ST7789_Fill(INV_C_BLACK);

    // Center-ish Bop-It logo sprite
    int logo_x = 20;
    int logo_y = 30;
    DrawBopItLogoSprite(logo_x, logo_y);

    // Prompt text below
    ST7789_DrawStringStatic("Press SW2 to START", INV_C_YELLOW, 20, logo_y + 60);

    G8RTOS_SignalSemaphore(&sem_SPIA);
}


static void DrawCountdown(int n)
{
    char buf[8];
    sprintf(buf, "%d...", n);

    G8RTOS_WaitSemaphore(&sem_SPIA);
    ST7789_DrawRectangle(70, 80, 160, 20, INV_C_BLACK);
    ST7789_DrawStringStatic(buf, INV_C_WHITE, 70, 80);
    G8RTOS_SignalSemaphore(&sem_SPIA);
}

static void DrawGame(BopCommand_t cmd, int timeLeft, int score)
{
    char buf[20];

    G8RTOS_WaitSemaphore(&sem_SPIA);
    ST7789_DrawRectangle(30, 5, 200, 100, INV_C_BLACK);

    ST7789_DrawStringStatic(cmdText[cmd], INV_C_GREEN, 35, 50);

    sprintf(buf, "Time:%d", timeLeft);
    ST7789_DrawStringStatic(buf, INV_C_WHITE, 40, 80);

    sprintf(buf, "Pts:%d", score);
    ST7789_DrawStringStatic(buf, INV_C_YELLOW, X_MAX - 80, 10);

    G8RTOS_SignalSemaphore(&sem_SPIA);
}

static void DrawTime(int t)
{
    char buf[12];

    G8RTOS_WaitSemaphore(&sem_SPIA);
    ST7789_DrawRectangle(40, 80, 160, 20, INV_C_BLACK);
    sprintf(buf, "Time:%d", t);
    ST7789_DrawStringStatic(buf, INV_C_WHITE, 40, 80);
    G8RTOS_SignalSemaphore(&sem_SPIA);
}

static void DrawGameOver(int score)
{
    char buf[20];

    // Send "game over music" command = 8
    UARTCharPutNonBlocking(UART4_BASE, 8);

    G8RTOS_WaitSemaphore(&sem_SPIA);
    ST7789_Fill(INV_C_RED);

    ST7789_DrawStringStatic("GAME OVER!", INV_C_WHITE, 40, 80);

    sprintf(buf, "Score: %d", score);
    ST7789_DrawStringStatic(buf, INV_C_WHITE, 60, 100);

    ST7789_DrawStringStatic("Press SW2 to retry", INV_C_WHITE, 20, 130);

    G8RTOS_SignalSemaphore(&sem_SPIA);
}

/******************************************************
 * Bop-It Main Game Thread
 * - dynamic time: start 10s, -1s every 2 pts, min 3s
 ******************************************************/
void BopIt_Thread(void)
{
    srand(1234);

    while (1)
    {
        /************* STARTUP SCREEN *************/
        DrawWelcome();
        WaitForSW2Press();

        int score      = 0;
        int baseTime_s = 10;  // difficulty scaling

        ST7789_Fill(INV_C_BLACK);

        // Simple 3..2..1 countdown
        for (int i = 3; i >= 1; i--)
        {
            DrawCountdown(i);
            G8RTOS_Sleep(1000);
        }
        ST7789_DrawRectangle(70, 80, 160, 20, INV_C_BLACK);

        /************* MAIN GAME LOOP *************/
        while (1)
        {
            ActionFifo_Clear();

            // Every 2 points, shrink time (down to 3 seconds)
            if (score > 0 && (score % 2) == 0 && baseTime_s > 2)
                baseTime_s--;

            BopCommand_t cmd = (rand() % CMD_COUNT);
            int timeLeft = baseTime_s;
            int ms       = 0;

            /************* UART COMMAND SEND *************/
            UARTCharPutNonBlocking(UART4_BASE, (uint8_t)cmd);

            DrawGame(cmd, timeLeft, score);

            bool lost      = false;
            bool roundOver = false;

            while (!roundOver)
            {
                G8RTOS_Sleep(100);
                ms += 100;

                if (ms >= 1000)
                {
                    ms = 0;
                    timeLeft--;
                    DrawTime(timeLeft);

                    if (timeLeft <= 0)
                    {
                        lost = true;
                        break;
                    }
                }

                PlayerAction_t act = ActionFifo_Pop();
                if (act != ACT_NONE)
                {
                    bool correct = false;
                    switch (cmd)
                    {
                        case CMD_BOP:   correct = (act == ACT_BOP);   break;
                        case CMD_UP:    correct = (act == ACT_UP);    break;
                        case CMD_LEFT:  correct = (act == ACT_LEFT);  break;
                        case CMD_RIGHT: correct = (act == ACT_RIGHT); break;
                        case CMD_DOWN:  correct = (act == ACT_DOWN);  break;
                        case CMD_SHAKE: correct = (act == ACT_SHAKE); break;
                    }

                    if (correct)
                        score++;
                    else
                        lost = true;

                    break;
                }
            }

            if (lost)
            {
                /************* GAME OVER SCREEN *************/
                DrawGameOver(score);
                WaitForSW2Press();
                break;
            }
        }
    }
}

/******************************************************
 * BUTTON THREAD (SW1 + SW2)
 ******************************************************/
void Read_Buttons_Thread(void)
{
    static bool prev_sw1 = false;
    static bool prev_sw2 = false;

    while (1)
    {
        G8RTOS_WaitSemaphore(&sem_PCA9555_Debounce);

        G8RTOS_WaitSemaphore(&sem_I2CA);
        uint8_t b = MultimodButtons_Get();
        G8RTOS_SignalSemaphore(&sem_I2CA);

        bool sw1 = !(b & 0x02); // SW1
        bool sw2 = !(b & 0x04); // SW2

        // Bop-It action
        if (sw1 && !prev_sw1)
            ActionFifo_Push(ACT_BOP);

        // Start / re-start
        if (sw2 && !prev_sw2)
            g_sw2_event = true;

        prev_sw1 = sw1;
        prev_sw2 = sw2;

        G8RTOS_Sleep(20);
    }
}

/******************************************************
 * JOYSTICK THREAD
 ******************************************************/
void Read_Joystick_Thread(void)
{
    static bool ready = true;

    while (1)
    {
        uint32_t xy = JOYSTICK_GetXY();
        int x = ((xy >> 16) & 0xFFFF) - 2048;
        int y = (xy & 0xFFFF) - 2048;

        int ax = abs(x);
        int ay = abs(y);

        if (ax < 400 && ay < 400)
        {
            ready = true;
        }
        else if (ready)
        {
            ready = false;

            if (ay > ax)
            {
                if (y < -400)      ActionFifo_Push(ACT_UP);
                else if (y > 400)  ActionFifo_Push(ACT_DOWN);
            }
            else
            {
                if (x < -400)      ActionFifo_Push(ACT_LEFT);
                else if (x > 400)  ActionFifo_Push(ACT_RIGHT);
            }
        }

        G8RTOS_Sleep(50);
    }
}

/******************************************************
 * ACCELEROMETER THREAD — SHAKE-IT
 ******************************************************/
void Read_Accel_Thread(void)
{
    const int16_t BASE     = 16637;
    const int16_t TRIGGER  = 3000;
    const int16_t DEADZONE = 1500;

    static bool ready = true;

    while (1)
    {
        int16_t ay = BMI160_AccelYGetResult();
        int32_t diff  = ay - BASE;
        int32_t adiff = (diff >= 0) ? diff : -diff;

        if (adiff < DEADZONE)
            ready = true;
        else if (adiff > TRIGGER && ready)
        {
            ready = false;
            ActionFifo_Push(ACT_SHAKE);
        }

        G8RTOS_Sleep(50);
    }
}

/******************************************************
 * GPIOE Handler — PCA9555 Active-Low Interrupt
 ******************************************************/
void GPIOE_Handler(void)
{
    GPIOIntClear(GPIO_PORTE_BASE, GPIO_PIN_4);
    G8RTOS_SignalSemaphore(&sem_PCA9555_Debounce);
}

/******************************************************
 * Public Init for FIFO
 ******************************************************/
void BopIt_ActionFIFO_Init(void)
{
    ActionFifo_Init();
}
