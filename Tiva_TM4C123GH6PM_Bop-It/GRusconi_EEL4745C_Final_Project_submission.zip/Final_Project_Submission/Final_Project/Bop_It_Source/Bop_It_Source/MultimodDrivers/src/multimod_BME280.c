/*
 * multimod_BME280.c
 *
 *  Created on: Sep 11, 2024
 *      Author: hamid
 */


/************************************Includes***************************************/

#include "../multimod_BME280.h"

#include <stdint.h>
#include "../multimod_i2c.h"

#define BME280_ADDRESS      0x76
#define BME280_ID_REG       0xD0
#define BME280_CTRL_MEAS    0xF4
#define BME280_TEMP_MSB     0xFA
#define BME280_TEMP_LSB     0xFB
#define BME280_TEMP_XLSB    0xFC

#define BME280_DIG_T1_LSB   0x88
#define BME280_DIG_T1_MSB   0x89
#define BME280_DIG_T2_LSB   0x8A
#define BME280_DIG_T2_MSB   0x8B
#define BME280_DIG_T3_LSB   0x8C
#define BME280_DIG_T3_MSB   0x8D

static uint16_t dig_T1;
static int16_t  dig_T2, dig_T3;
static int32_t t_fine;

/************************************Includes***************************************/


void BME280_Init() {


    BME280_WriteRegister(BME280_CTRL_MEAS, 0x27);
    dig_T1 = BME280_ReadDig1();
    dig_T2 = (int16_t)BME280_ReadDig2();
    dig_T3 = (int16_t)BME280_ReadDig3();

}

void BME280_WriteRegister(uint8_t addr, uint8_t data) {

    I2C_Write(BME280_ADDRESS, addr, data);


}

uint32_t BME280_ReadOutput(uint8_t addr) {

    uint8_t msb = I2C_Read(BME280_ADDRESS, addr);
    uint8_t lsb = I2C_Read(BME280_ADDRESS, addr + 1);
    uint8_t xlsb = I2C_Read(BME280_ADDRESS, addr + 2);

    uint32_t ret_val = ((uint32_t)msb << 12) | ((uint32_t)lsb << 4) | ((uint32_t)(xlsb >> 4));
    return (ret_val);

}

uint16_t BME280_ReadDig1(void) {

    uint8_t lsb = I2C_Read(BME280_ADDRESS, BME280_DIG_T1_LSB);
    uint8_t msb = I2C_Read(BME280_ADDRESS, BME280_DIG_T1_MSB);
    uint8_t ret_val = (((uint16_t)msb << 8) | lsb);
    return (ret_val);

}

uint16_t BME280_ReadDig2(void) {

    uint8_t lsb = I2C_Read(BME280_ADDRESS, BME280_DIG_T2_LSB);
    uint8_t msb = I2C_Read(BME280_ADDRESS, BME280_DIG_T2_MSB);
    uint8_t ret_val = (((uint16_t)msb << 8) | lsb);
    return (ret_val);

}

uint16_t BME280_ReadDig3(void) {

    uint8_t lsb = I2C_Read(BME280_ADDRESS, BME280_DIG_T3_LSB);
    uint8_t msb = I2C_Read(BME280_ADDRESS, BME280_DIG_T3_MSB);
    uint8_t ret_val = (((uint16_t)msb << 8) | lsb);
    return (ret_val);

}

uint32_t BME280_ReadTemp(void) {

    return BME280_ReadOutput(BME280_TEMP_MSB);

}

uint8_t BME280_ID(void) {

    return I2C_Read(BME280_ADDRESS, BME280_ID_REG);

}

int32_t BME280_Convert(uint32_t adc_T) {

    int32_t var1;
    int32_t var2;
    int32_t T;

    var1 = ((((adc_T >> 3) - ((int32_t)dig_T1 << 1))) * ((int32_t)dig_T2)) >> 11;
    var2 = (((((adc_T >> 4) - ((int32_t)dig_T1)) * ((adc_T >> 4) - ((int32_t)dig_T1))) >> 12) *
            ((int32_t)dig_T3)) >> 14;

    t_fine = var1 + var2;

    T = (t_fine * 5 + 128) >> 8; // Celsius *100
    return T;


}

