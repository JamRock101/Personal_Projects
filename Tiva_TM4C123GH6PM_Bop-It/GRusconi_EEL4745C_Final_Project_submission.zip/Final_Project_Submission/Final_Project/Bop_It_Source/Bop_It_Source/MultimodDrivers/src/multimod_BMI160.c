// multimod_BMI160.c
// Date Created: 2023-07-25
// Date Updated: 2023-07-27
// Defines for BMI160 functions

/************************************Includes***************************************/

#include "../multimod_BMI160.h"

#include <stdint.h>
#include "../multimod_i2c.h"

/************************************Includes***************************************/
#define BMI160_I2C_ADDR 0x69
#define BMI160_REG_ACCEL_X_LSB 0x12
#define BMI160_REG_ACCEL_Y_LSB 0x14
#define BMI160_REG_ACCEL_Z_LSB 0x16
#define BMI160_REG_GYRO_X_LSB 0x0C
#define BMI160_REG_GYRO_Y_LSB 0x0E
#define BMI160_REG_GYRO_Z_LSB 0x10
#define BMI160_REG_MAG_X_LSB 0x04
#define BMI160_REG_STATUS 0x1B
/********************************Public Functions***********************************/

// BMI160_Init
// Initializes the BMI160. Currently enables the accelerometer
// in full-power mode.
// Return: void
//void BMI160_Init(void) {
//    I2C_Init(1);
//
//    // Power on accelerometer
//    // your code here
//
//        //bmi160 is big endian, msb first then lsb
//        // CMD reg (0x7E), continuous conversions, default range
//        uint8_t data[3];
//        data[0] = 0x7E;               // Register pointer = CMD
//        data[1] = 0x11;               // turn on Accel mode
//        data[2] = 0x15; // turn on gyro mode
//        data[3] = 0x18; //turn on magneto mode
//
//
//        I2C_WriteMultiple(1, BMI160_I2C_ADDR, data, 4);
//
//        return;
//
//}

void BMI160_Init(void) {
    I2C_Init(1);

    BMI160_WriteRegister(BMI160_CMD_ADDR, 0x06);
    SysCtlDelay(1600000/30);

    BMI160_WriteRegister(BMI160_CMD_ADDR, 0x11);
    SysCtlDelay(1600000/30);

    BMI160_WriteRegister(BMI160_CMD_ADDR, 0x15);
    SysCtlDelay(1600000/30);

    BMI160_WriteRegister(BMI160_ACCCONF_ADDR, (0x20 | 0x08));

    BMI160_WriteRegister(BMI160_GYRCONFG_ADDR, (0x20 | 0x08));

    BMI160_WriteRegister(BMI160_ACCRANGE_ADDR, 0x03);

    BMI160_WriteRegister(BMI160_GYRRANGE_ADDR, 0x00);


        return;

}

// BMI160_Init
// Writes to a register address in the BMI160.
// Param uint8_t "addr": Register address
// Param uint8_t "data": data to write
// Return: void
void BMI160_WriteRegister(uint8_t addr, uint8_t data) {
    // write a single register
    // write where?
            // your code here

    // with what? (hint youre writing only 1 data item, but you still need to specify where)
            // your code here

    uint8_t tx[2];
    tx[0] = addr;  // register address
    tx[1] = data;  // data

    // write I2C device
    I2C_WriteMultiple(1, BMI160_I2C_ADDR, tx, 2);
}

// BMI160_ReadRegister
// Reads from a register address in the BMI160.
// Param uint8_t "addr": Register address
// Return: void
uint8_t BMI160_ReadRegister(uint8_t addr) {
    // read from which addr?
    uint8_t ret_data;
    // your code here
    I2C_WriteSingle(1, BMI160_I2C_ADDR, addr);
    ret_data = I2C_ReadSingle(1, BMI160_I2C_ADDR);
    // return the data
    return ret_data; // your code here
}

// BMI160_MultiReadRegister
// Uses the BMI160 auto-increment function to read from multiple registers.
// Param uint8_t "addr": beginning register address
// Param uint8_t* "data": pointer to an array to store data in
// Param uint8_t "num_bytes": number of bytes to read
// Return: void
void BMI160_MultiReadRegister(uint8_t addr, uint8_t* data, uint8_t num_bytes) {
    // write to which addr?
    I2C_WriteSingle(1, BMI160_I2C_ADDR, addr);
    // your code here

    // read the data from that addr

    // your code here
    I2C_ReadMultiple(1, BMI160_I2C_ADDR, data, num_bytes);

    return;
}

// BMI160_AccelXGetResult
// Gets the 16-bit x-axis acceleration result.
// Return: uint16_t
int16_t BMI160_AccelXGetResult() {
//    while (!(BMI160_GetDataStatus() & BMI160_STATUS_DRDY_ACC));
    // if not read, wait till read
    uint8_t raw[2];
        // your code here

    // read data
        // your code here

    // write data
    BMI160_MultiReadRegister(BMI160_REG_ACCEL_X_LSB, raw, 2);


        // your code here

    return ((raw[1] << 8) | raw[0]);
}

// BMI160_AccelYGetResult
// Gets the 16-bit y-axis acceleration result.
// Return: uint16_t
int16_t BMI160_AccelYGetResult() {
 //   while (!(BMI160_GetDataStatus() & BMI160_STATUS_DRDY_ACC));
    uint8_t raw[2];
        // your code here

    // read data
        // your code here

    // write data
    BMI160_MultiReadRegister(BMI160_REG_ACCEL_Y_LSB, raw, 2);

        // your code here

    return ((raw[1] << 8) | raw[0]);
}

// BMI160_AccelZGetResult
// Gets the 16-bit z-axis acceleration result.
// Return: uint16_t
int16_t BMI160_AccelZGetResult() {
    while (!(BMI160_GetDataStatus() & BMI160_STATUS_DRDY_ACC));

    uint8_t raw[2];
            // your code here

    // read data
        // your code here

    // write data
    BMI160_MultiReadRegister(BMI160_REG_ACCEL_Z_LSB, raw, 2);


        // your code here

    return ((raw[1] << 8) | raw[0]);


}

// BMI160_GyroXGetResult
// Gets the 16-bit x-axis gyroscope result.
// Return: uint16_t
int16_t BMI160_GyroXGetResult() {
    while (!(BMI160_GetDataStatus() & BMI160_STATUS_DRDY_GYR));
    uint8_t raw[2];
            // your code here

    // read data
        // your code here

    // write data
    BMI160_MultiReadRegister(BMI160_REG_GYRO_X_LSB, raw, 2);

        // your code here

    return ((raw[1] << 8) | raw[0]);
}

// BMI160_GyroYGetResult
// Gets the 16-bit y-axis gyroscope result.
// Return: uint16_t
int16_t BMI160_GyroYGetResult() {
//    while (!(BMI160_GetDataStatus() & BMI160_STATUS_DRDY_GYR));

    uint8_t raw[2];
                // your code here

        // your code here

    // write data
    BMI160_MultiReadRegister(BMI160_REG_GYRO_Y_LSB, raw, 2);
        // your code here

    return ((raw[1] << 8) | raw[0]);
}

// BMI160_GyroZGetResult
// Gets the 16-bit z-axis gyroscope result.
// Return: uint16_t
int16_t BMI160_GyroZGetResult() {
    while (!(BMI160_GetDataStatus() & BMI160_STATUS_DRDY_GYR));
    uint8_t raw[2];
                    // your code here
        // your code here

    // write data
    BMI160_MultiReadRegister(BMI160_REG_GYRO_Z_LSB, raw, 2);

        // your code here

    return ((raw[1] << 8) | raw[0]);
}

// BMI160_AccelXYZGetResult
// Stores the 16-bit XYZ accelerometer results in an array.
// Param uint16_t* "data": pointer to an array of 16-bit data.
// Return: void
void BMI160_AccelXYZGetResult(uint16_t* data) {
    uint8_t raw[6];
    while (!(BMI160_GetDataStatus() & BMI160_STATUS_DRDY_ACC));
    BMI160_MultiReadRegister(BMI160_REG_ACCEL_X_LSB, raw, 6);
    data[0] = (int16_t)((raw[1] << 8) | raw[0]); // X
    data[1] = (int16_t)((raw[3] << 8) | raw[2]); // Y
    data[2] = (int16_t)((raw[5] << 8) | raw[4]); // Z

    return;
}

// BMI160_GyroXYZGetResult
// Stores the 16-bit XYZ gyroscope results in an array.
// Param uint16_t* "data": pointer to an array of 16-bit data.
// Return: void
void BMI160_GyroXYZGetResult(uint16_t* data) {

    uint8_t raw[6];

    while (!(BMI160_GetDataStatus() & BMI160_STATUS_DRDY_GYR));

    BMI160_MultiReadRegister(BMI160_REG_GYRO_X_LSB, raw, 6);
    data[0] = (int16_t)((raw[1] << 8) | raw[0]); // X
    data[1] = (int16_t)((raw[3] << 8) | raw[2]); // Y
    data[2] = (int16_t)((raw[5] << 8) | raw[4]); // Z

    return;
}

// BMI160_GetDataStatus
// Gets the status register to determine if data is ready to read.
// Return: uint8_t
uint8_t BMI160_GetDataStatus() {
    return BMI160_ReadRegister(BMI160_REG_STATUS);

}

int16_t BMI160_MagXGetResult() {
    while (!(BMI160_GetDataStatus() & BMI160_STATUS_DRDY_MAG));
    uint8_t raw[2];
                    // your code here
        // your code here

    // write data
    BMI160_MultiReadRegister(BMI160_REG_MAG_X_LSB, raw, 2);

        // your code here

    return ((raw[1] << 8) | raw[0]);
}

/********************************Public Functions***********************************/

