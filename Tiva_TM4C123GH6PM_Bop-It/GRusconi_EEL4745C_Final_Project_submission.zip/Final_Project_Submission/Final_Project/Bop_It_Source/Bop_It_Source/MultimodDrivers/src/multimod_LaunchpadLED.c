// multimod_OPT3001.c
// Date Created: 2023-07-25
// Date Updated: 2023-07-27
// Defines for OPT3001 functions

/************************************Includes***************************************/

#include "../multimod_LaunchpadLED.h"

#include <stdint.h>
#include <stdbool.h>

#include <inc/tm4c123gh6pm.h>
#include <inc/hw_types.h>
#include <inc/hw_memmap.h>
#include <inc/hw_gpio.h>

#include <driverlib/pin_map.h>
#include <driverlib/pwm.h>
#include <driverlib/gpio.h>
#include <driverlib/sysctl.h>

/************************************Includes***************************************/
#define PWM_Per 320
/********************************Public Functions***********************************/

// LaunchpadButtons_Init
// Initializes the GPIO port & pins necessary for the button switches on the
// launchpad. Also configures it so that the LEDs are controlled via PWM signal.
// Initial default period of 320 for 16 MHz.
// Return: void
void LaunchpadLED_Init() {
    // Enable clock to port F
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);
    while(!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOF)){} // await finished

    // Enable PWM module

    SysCtlPeripheralEnable(SYSCTL_PERIPH_PWM1);
    while(!SysCtlPeripheralReady(SYSCTL_PERIPH_PWM1)){} // for all pwm and gen and modules



    // Configure necessary pins as PWM
    GPIOPinConfigure(GPIO_PF1_M1PWM5); // for gen2/pwm5/pin1/red_led
    GPIOPinConfigure(GPIO_PF2_M1PWM6); // for gen3/pwm6/pin2/blue_led
    GPIOPinConfigure(GPIO_PF3_M1PWM7); // for gen3/pwm7/pin3/green_led
    GPIOPinTypePWM(GPIO_PORTF_BASE, GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3); // for pin1/red_led, pin2/blue_led, pin3/green_led

    // Configure necessary PWM generators in count down mode, no sync
    PWMGenConfigure(PWM1_BASE, PWM_GEN_2, PWM_GEN_MODE_DOWN | PWM_GEN_MODE_NO_SYNC); // for gen2
    PWMGenConfigure(PWM1_BASE, PWM_GEN_3, PWM_GEN_MODE_DOWN | PWM_GEN_MODE_NO_SYNC); // for gen3


    // Set generator periods
    PWMGenPeriodSet(PWM1_BASE, PWM_GEN_2, PWM_Per); // for gen2
    PWMGenPeriodSet(PWM1_BASE, PWM_GEN_3, PWM_Per); // for gen3


    // Set the default pulse width (duty cycles).
    PWMPulseWidthSet(PWM1_BASE, PWM_OUT_5, PWM_Per); // for gen2/pwm5/pin1/red_led
    PWMPulseWidthSet(PWM1_BASE, PWM_OUT_6, PWM_Per); // for gen3/pwm6/pin2/blue_led
    PWMPulseWidthSet(PWM1_BASE, PWM_OUT_7, PWM_Per); // for gen3/pwm7/pin3/green_led

    // Enable the PWM generators
    PWMGenEnable(PWM1_BASE, PWM_GEN_2); // for gen2
    PWMGenEnable(PWM1_BASE, PWM_GEN_3); // for gen3


    // Enable PWM output
    PWMOutputState(PWM1_BASE, PWM_OUT_5_BIT | PWM_OUT_6_BIT | PWM_OUT_7_BIT, true); // for pin1/red_led, pin2/blue_led, pin3/green_led

}

// LaunchpadLED_PWMSetDuty
// Sets the duty cycle of the PWM generator associated with the LED.
// Return: void
float pulse_width;

void LaunchpadLED_PWMSetDuty(LED_Color_t LED, float duty) {
    //pulse_width = (duty * PWM_Per);
    pulse_width = (duty * 1);

    // If pulse width < 1, set as 1
    if (pulse_width < 1){

        pulse_width = 1;

    }

    if (pulse_width >= PWM_Per){

        // If pulse width > set period, cap it

        pulse_width = PWM_Per;

    }

    // Depending on chosen LED(s), adjust corresponding duty cycle of the PWM output

    switch(LED) {
        case RED:
            PWMPulseWidthSet(PWM1_BASE, PWM_OUT_5, pulse_width);
            break;
        case BLUE:
            PWMPulseWidthSet(PWM1_BASE, PWM_OUT_6, pulse_width);
            break;
        case GREEN:
            PWMPulseWidthSet(PWM1_BASE, PWM_OUT_7, pulse_width);
            break;
        default:
            break;
        }
    return;
}

/********************************Public Functions***********************************/
