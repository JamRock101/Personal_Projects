// Lab 5 - Part B: Real-Time Audio Output System
// - Generate tones with DAC
// - Control frequency via buttons
// - Control volume via joystick
// - Use RTOS threads, semaphores, interrupts

/************************************Includes***************************************/
#include "G8RTOS/G8RTOS.h"
#include "./MultimodDrivers/multimod.h"

#include "./threads.h"

#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"
#include "driverlib/interrupt.h"
#include "driverlib/timer.h"
#include "inc/hw_memmap.h"


#include <stdint.h>
#include <stdbool.h>

#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"
#include "driverlib/pin_map.h"
#include "driverlib/uart.h"

#include "./MultimodDrivers/multimod_i2c.h"
#include "./MultimodDrivers/multimod_BMI160.h"
#include "./MultimodDrivers/multimod_uart.h"   // for UARTprintf

// Simple delay


int main(void)
{
    /**************** CLOCK ****************/
    SysCtlClockSet(
        SYSCTL_SYSDIV_1 |
        SYSCTL_USE_OSC |
        SYSCTL_OSC_MAIN |
        SYSCTL_XTAL_16MHZ
    );

    UART_Init();

    UARTprintf("\n=== BMI160 Test Program ===\n");

    /**************** I2C & BMI160 INIT ****************/
    I2C_Init(1);       // multimod I2C1 init
    BMI160_Init();     // your BMI160 init routine

    UARTprintf("BMI160 Initialized.\n");

    while (1)
    {
        /******** ACCEL VALUES ********/
        int16_t ax = BMI160_AccelXGetResult();
        int16_t ay = BMI160_AccelYGetResult();
        int16_t az = BMI160_AccelZGetResult();

        /******** GYRO VALUES ********/
        int16_t gx = BMI160_GyroXGetResult();
        int16_t gy = BMI160_GyroYGetResult();
        int16_t gz = BMI160_GyroZGetResult();

        // Output all values
        UARTprintf("ACCEL  X:%d  Y:%d  Z:%d\n", ax, ay, az);
        UARTprintf("GYRO   X:%d  Y:%d  Z:%d\n\n", gx, gy, gz);

   //     delay_ms(200);
    }
}


