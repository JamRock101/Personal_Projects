// G8RTOS_Semaphores.c
// Date Created: 2023-07-25
// Date Updated: 2023-07-27
// Defines for semaphore functions

#include "../G8RTOS_Semaphores.h"
#include "../G8RTOS_Scheduler.h"
#include "inc/hw_types.h"
#include "inc/hw_ints.h"
#include "inc/hw_nvic.h"
#include "driverlib/systick.h"
#include "driverlib/sysctl.h"
#include "driverlib/interrupt.h"

/************************************Includes***************************************/

#include "../G8RTOS_CriticalSection.h"


/************************************Includes***************************************/

/******************************Data Type Definitions********************************/
/******************************Data Type Definitions********************************/

/****************************Data Structure Definitions*****************************/
/****************************Data Structure Definitions*****************************/

/***********************************Externs*****************************************/
/***********************************Externs*****************************************/

/********************************Public Variables***********************************/

int32_t IBit_State;
extern int32_t StartCriticalSection();

/********************************Public Variables***********************************/

/********************************Public Functions***********************************/

// G8RTOS_InitSemaphore
// Initializes semaphore to a value. This is a critical section!
// Param "s": Pointer to semaphore
// Param "value": Value to initialize semaphore to
// Return: void
void G8RTOS_InitSemaphore(semaphore_t* s, int32_t value) {

    *s = value;                     // not s = value
}


//void G8RTOS_WaitSemaphore(semaphore_t* s) {
//    uint32_t m = StartCriticalSection();
//    while (*s == 0){
//        EndCriticalSection(m);
//        m = StartCriticalSection();
//    }
//    (*s)--;
//    EndCriticalSection(m);
//}


void G8RTOS_WaitSemaphore(semaphore_t* s) {
    uint32_t m = StartCriticalSection();
    (*s)--;
    if (*s < 0){

        CurrentlyRunningThread -> blocked = s;
        EndCriticalSection(m);
        HWREG(NVIC_INT_CTRL) |= NVIC_INT_CTRL_PEND_SV;
        return;
    }

    EndCriticalSection(m);
}


//void G8RTOS_SignalSemaphore(semaphore_t* s) {
//    (*s)++;
//}


void G8RTOS_SignalSemaphore(semaphore_t* s) {
    uint32_t m = StartCriticalSection();
    (*s)++;

    if((*s) <= 0){

        tcb_t *pt = CurrentlyRunningThread -> nextTCB;
        CurrentlyRunningThread -> blocked = 0;
        while(pt != CurrentlyRunningThread){
            if (pt -> blocked == s){
                pt -> blocked = 0;
                break;
            }
            pt = pt -> nextTCB;
        }

        pt -> blocked = 0;

    }
    EndCriticalSection(m);
}



/********************************Public Functions***********************************/
