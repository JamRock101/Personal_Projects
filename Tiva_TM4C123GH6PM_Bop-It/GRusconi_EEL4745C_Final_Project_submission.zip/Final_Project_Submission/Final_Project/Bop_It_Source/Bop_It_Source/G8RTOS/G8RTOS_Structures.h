// G8RTOS_Structures.h
// Date Created: 2023-07-26
// Date Updated: 2023-07-26
// Thread block definitions

#ifndef G8RTOS_STRUCTURES_H_
#define G8RTOS_STRUCTURES_H_

/************************************Includes***************************************/

#include <stdbool.h>
#include <stdint.h>

#include "G8RTOS_Structures.h"
#include "G8RTOS_Semaphores.h"

/************************************Includes***************************************/

/*************************************Defines***************************************/

#define MAX_NAME_LENGTH             16

/*************************************Defines***************************************/

/******************************Data Type Definitions********************************/

// Thread ID
typedef int32_t threadID_t;


/******************************Data Type Definitions********************************/
typedef int32_t semaphore_t;
/****************************Data Structure Definitions*****************************/

/*
 *  Thread Control Block:
 *      - Every thread has a Thread Control Block
 *      - The Thread Control Block holds information about the Thread Such as
 *        the Stack Pointer, Priority Level, and Blocked Status
 *      - For Lab 3 the TCB will only hold the Stack Pointer, next TCB and the
 *        previous TCB (for Round Robin Scheduling)
 *  Create thread control block structure here
 *      - pay close attention to the order of variables!
 * */
//typedef struct tcb_t { //slides template = true
//    uint32_t *StackPointer;             // stack pointer for this thread
//    struct tcb_t *next;      // pointer to next TCB (circular linked list)
//    struct tcb_t *prev;      // pointer to previous TCB
//    // Blocking and sleeping support
////    semaphore_t *blocked;       // 0 if not blocked, otherwise pointer to semaphore
////    uint32_t sleepCount;   // used for sleeping threads
//
//} tcb_t;

typedef struct tcb_t { //slides template = true

    uint32_t *StackPointer;             // stack pointer for this thread
    uint32_t ThreadID;
    char ThreadName[MAX_NAME_LENGTH];
    bool isAlive;
    uint8_t Priority;
    bool asleep;
    uint32_t sleepCount;
    semaphore_t *blocked;

    struct tcb_t *previousTCB;      // pointer to previous TCB
    struct tcb_t *nextTCB;      // pointer to next TCB (circular linked list)

    // 0 if not blocked, otherwise pointer to semaphore
       // used for sleeping threads

} tcb_t;

typedef struct ptcb_t {

    void (*handler) (void);
    uint32_t period;
    uint32_t executeTime;
    uint32_t currentTime;
    struct ptcb_t *previousPTCB;
    struct ptcb_t *nextPTCB;

} ptcb_t;



extern tcb_t *CurrentlyRunningThread;
/****************************Data Structure Definitions*****************************/

/********************************Public Variables***********************************/
/********************************Public Variables***********************************/

/********************************Public Functions***********************************/
/********************************Public Functions***********************************/

/*******************************Private Variables***********************************/
/*******************************Private Variables***********************************/

/*******************************Private Functions***********************************/
/*******************************Private Functions***********************************/

#endif /* G8RTOS_STRUCTURES_H_ */
