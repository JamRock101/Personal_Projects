// G8RTOS_Semaphores.h
// Date Created: 2023-07-26
// Date Updated: 2023-07-26
// Semaphores

#ifndef G8RTOS_SEMAPHORES_H_
#define G8RTOS_SEMAPHORES_H_

/************************************Includes***************************************/

#include <stdint.h>
#include "G8RTOS_Structures.h"

/************************************Includes***************************************/

/*************************************Defines***************************************/
/*************************************Defines***************************************/

/******************************Data Type Definitions********************************/

// Semaphore typedef
// your stuff goes here

// Semaphore instantiation
// your stuff goes here

/******************************Data Type Definitions********************************/

/****************************Data Structure Definitions*****************************/
/****************************Data Structure Definitions*****************************/

typedef int32_t semaphore_t;
/********************************Public Functions***********************************/


void G8RTOS_InitSemaphore(semaphore_t* s, int32_t value);
void G8RTOS_WaitSemaphore(semaphore_t* s);
void G8RTOS_SignalSemaphore(semaphore_t* s);

extern semaphore_t sem_UART;
extern semaphore_t sem_I2CA;
extern semaphore_t sem_KillCube;
extern semaphore_t sem_Joystick_Debounce;
extern semaphore_t sem_PCA9555_Debounce;
extern semaphore_t sem_SPIA;
extern semaphore_t sem_Joystick;

/********************************Public Functions***********************************/

/*******************************Private Variables***********************************/
/*******************************Private Variables***********************************/

/*******************************Private Functions***********************************/
/*******************************Private Functions***********************************/

#endif /* G8RTOS_SEMAPHORES_H_ */

