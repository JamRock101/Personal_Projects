/******************************************************
 * Bop-It Final Project � main.c  (NO SPIN VERSION)
 * Author: Giorgio Rusconi
 ******************************************************/

#include <stdint.h>
#include <stdbool.h>

#include "inc/hw_memmap.h"
#include "inc/hw_ints.h"
#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"

#include "G8RTOS/G8RTOS.h"
#include "./MultimodDrivers/multimod.h"
#include "./MultimodDrivers/multimod_ST7789.h"
#include "./MultimodDrivers/multimod_BMI160.h"
#include "./threads.h"

/************ Extern Semaphores *************/
extern semaphore_t sem_SPIA;
extern semaphore_t sem_UART;
extern semaphore_t sem_I2CA;
extern semaphore_t sem_PCA9555_Debounce;

/************ Thread Prototypes *************/
extern void Idle_Thread(void);
extern void BopIt_Thread(void);
extern void Read_Buttons_Thread(void);
extern void Read_Joystick_Thread(void);
extern void Read_Accel_Thread(void);
extern void GPIOE_Handler(void);
extern void BopIt_ActionFIFO_Init(void);

/******************************************************
 * Init PCA9555 Interrupt (PE4)
 ******************************************************/
static void Init_PE4_Interrupt(void)
{
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOE);
    while (!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOE));

    GPIOPinTypeGPIOInput(GPIO_PORTE_BASE, GPIO_PIN_4);

    GPIOIntTypeSet(GPIO_PORTE_BASE, GPIO_PIN_4, GPIO_FALLING_EDGE);
    GPIOIntClear(GPIO_PORTE_BASE, GPIO_PIN_4);
    GPIOIntEnable(GPIO_PORTE_BASE, GPIO_PIN_4);
}

/******************************************************
 * main()
 ******************************************************/
int main(void)
{
    SysCtlClockSet(SYSCTL_SYSDIV_1 | SYSCTL_USE_OSC |
                   SYSCTL_OSC_MAIN | SYSCTL_XTAL_16MHZ);

    multimod_init();
    ST7789_Init();
    BMI160_Init();
    UART_BeagleBone_Init();

    G8RTOS_Init();

    G8RTOS_InitSemaphore(&sem_SPIA, 1);
    G8RTOS_InitSemaphore(&sem_UART, 1);
    G8RTOS_InitSemaphore(&sem_I2CA, 1);
    G8RTOS_InitSemaphore(&sem_PCA9555_Debounce, 0);

    BopIt_ActionFIFO_Init();

    Init_PE4_Interrupt();

    G8RTOS_AddThread(Idle_Thread,        255, "idle");
    G8RTOS_AddThread(BopIt_Thread,        10, "bopit");
    G8RTOS_AddThread(Read_Buttons_Thread, 20, "buttons");
    G8RTOS_AddThread(Read_Joystick_Thread,20, "joystick");
    G8RTOS_AddThread(Read_Accel_Thread,   20, "accel");

    G8RTOS_Add_APeriodicEvent(GPIOE_Handler, 3, INT_GPIOE);

    G8RTOS_Launch();
    while (1);
}
