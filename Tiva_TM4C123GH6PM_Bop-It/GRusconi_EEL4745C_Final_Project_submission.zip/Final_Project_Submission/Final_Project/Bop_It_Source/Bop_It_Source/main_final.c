// Lab 5 - Part B: Real-Time Audio Output System
// - Generate tones with DAC
// - Control frequency via buttons
// - Control volume via joystick
// - Use RTOS threads, semaphores, interrupts

/************************************Includes***************************************/
#include "G8RTOS/G8RTOS.h"
#include "./MultimodDrivers/multimod.h"
#include "./MultimodDrivers/multimod_dac.h"
#include "./MultimodDrivers/multimod_joystick.h"
#include "./MultimodDrivers/multimod_LaunchpadButtons.h"

#include "./threads.h"

#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"
#include "driverlib/interrupt.h"
#include "driverlib/timer.h"
#include "inc/hw_memmap.h"



///************************************MAIN*******************************************/
//int main(void)
//{
//    // 1) System clock (16 MHz)
//    SysCtlClockSet(SYSCTL_SYSDIV_2_5 | SYSCTL_USE_PLL | SYSCTL_OSC_MAIN | SYSCTL_XTAL_16MHZ);
//
//    SysCtlDelay(10);
//
//    // 2) Init Multimod + LCD + RTOS
//    ST7789_Init();
//    multimod_init();
//    G8RTOS_Init();
//
//    // 3) Init semaphores
//    G8RTOS_InitSemaphore(&sem_UART, 1);
//    G8RTOS_InitSemaphore(&sem_I2CA, 1);
//    G8RTOS_InitSemaphore(&sem_PCA9555_Debounce, 0);     // wait for button IRQ
//
//    // 4) Init FIFOs
//    G8RTOS_InitFIFO(BUTTONS_FIFO);
//    G8RTOS_InitFIFO(JOYSTICK_FIFO);           // re-use for volume path
//
//    // 5) Initialize DAC + audio engine (Timer1 + ISR + sine table)
//    //Audio_Init();
//
//    // 6) Configure button interrupt → Button_Handler
//    // (If not already done inside Multimod_Init)
//
//    // 7) Add Part A threads (already working in your code)
//    // G8RTOS_AddThread(Mic_Thread,      <priority>, "Mic\0");
//    // G8RTOS_AddThread(Display_Thread,  <priority>, "Disp\0");
//
//    // 8) Add Part B threads
//    G8RTOS_AddThread(Idle_Thread, 254, "Idle_Thread\0");
//    G8RTOS_AddThread(Speaker_Thread, 1, "Speaker\0");
//    G8RTOS_AddThread(Volume_Thread,  5, "Volume\0");
//    G8RTOS_AddThread(Read_Buttons,   3, "Buttons\0");
//
//    // 9) Add periodic event for Update_Volume (e.g., every 10 ms)
//    // Period is in system ticks (ms if SysTick is 1 kHz in your G8RTOS)
//    G8RTOS_Add_PeriodicEvent(Update_Volume, 10, 1);
//    G8RTOS_Add_APeriodicEvent(Button_Handler, 1, 20);
//
//    // 10) Launch RTOS
//    G8RTOS_Launch();
//
//    while (1) { } // should never reach here
//}


/****************************************************
 *                    main.c
 *       FINAL — Lab 6 Part-B Integrated Code
 ****************************************************/

#include <stdint.h>
#include <stdbool.h>

#include "inc/hw_memmap.h"
#include "inc/hw_ints.h"
#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"
#include "driverlib/interrupt.h"



#include "./G8RTOS/G8RTOS.h"
#include "./MultimodDrivers/multimod.h"
#include "./MultimodDrivers/multimod_dac.h"

extern void Speaker_Thread(void);
extern void Volume_Thread(void);
extern void Read_Buttons(void);
extern void Update_Volume(void);
extern void DAC_Timer_Handler(void);

semaphore_t sem_UART;
semaphore_t sem_I2CA;
semaphore_t sem_PCA9555_Debounce;

int main(void)
{
    // 1) System clock (16 MHz)
    SysCtlClockSet(SYSCTL_SYSDIV_2_5 | SYSCTL_USE_PLL | SYSCTL_OSC_MAIN | SYSCTL_XTAL_16MHZ);

    SysCtlDelay(10);

    // 2) Init Multimod + LCD + RTOS
    ST7789_Init();
    multimod_init();
    G8RTOS_Init();

    G8RTOS_InitSemaphore(&sem_UART, 1);
    G8RTOS_InitSemaphore(&sem_I2CA, 1);
    G8RTOS_InitSemaphore(&sem_PCA9555_Debounce, 0);

    G8RTOS_InitFIFO(0); // JOYSTICK FIFO


    G8RTOS_AddThread(Speaker_Thread, 3, "Spkr");
    G8RTOS_AddThread(Volume_Thread, 3, "Vol");
    G8RTOS_AddThread(Read_Buttons, 2, "Btns");

    G8RTOS_Add_PeriodicEvent(Update_Volume, 20, 1);
    G8RTOS_Add_APeriodicEvent(Button_Handler, 1, 20);
    G8RTOS_Add_APeriodicEvent(DAC_Timer_Handler, 2, 37);

    G8RTOS_Launch();

    while(1);
}


