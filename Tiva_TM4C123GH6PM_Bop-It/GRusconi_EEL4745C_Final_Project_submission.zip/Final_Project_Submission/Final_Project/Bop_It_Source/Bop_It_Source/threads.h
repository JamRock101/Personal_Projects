// threads.h
// Date Created: 2023-07-26
// Date Updated: 2023-07-26
// Threads

#ifndef THREADS_H_
#define THREADS_H_

/************************************Includes***************************************/

#include "./G8RTOS/G8RTOS.h"

/************************************Includes***************************************/

/*************************************Defines***************************************/
#define SPAWNCOOR_FIFO 0
#define JOYSTICK_FIFO 1
#define EXTRACREDIT_FIFO 2

#define COMMAND_FIFO   3

#define JOYSTICK_CMD_FIFO 0
#define BUTTON_CMD_FIFO 1
#define START_FIFO 2
#define TIMER_FIFO   3

#define ACTION_FIFO 0



#define JOY_FIFO 0
#define ACCEL_FIFO 1
#define GYRO_FIFO 2
#define SW1_FIFO   1
#define SW2_FIFO   2


/*************************************Defines***************************************/

/***********************************Semaphores**************************************/

extern semaphore_t sem_SPIA;
extern semaphore_t sem_I2CA;
extern semaphore_t sem_UART;


/***********************************Semaphores**************************************/

/***********************************Structures**************************************/
/***********************************Structures**************************************/


/*******************************Background Threads**********************************/

void Idle_Thread(void);
void UI_Thread(void);
void Command_Thread(void);
void Input_Check_Thread(void);
void Get_Joystick(void);
void Round_Timer_Event(void);


/*******************************Background Threads**********************************/

/********************************Periodic Threads***********************************/

void Update_Volume(void);

/********************************Periodic Threads***********************************/

/*******************************Aperiodic Threads***********************************/

void Mic_Handler(void);
void Button_Handler(void);
void DAC_Timer_Handler(void);
void GPIOE_Handler(void);
void Read_Buttons(void);
void BopIt_Game_Thread(void);
void Joystick_Read_Thread(void);
void Input_Thread(void);

void BopIt_Thread(void);
//void Audio_Init(void);

void Button_Thread(void);
void Joystick_Thread(void);
void StartButton_Thread(void);
void Timer_Thread(void);

void PlayerInput_Thread(void);
void Periodic_Read_SW1(void);

void Periodic_Read_Joystick(void);

void Periodic_PlayerInput(void);

void Read_buttons_Thread(void);
void Read_Joystick_Thread(void);
void Read_Accel_Thread(void);
void Read_Gyro_Thread(void);

/*******************************Aperiodic Threads***********************************/




#endif /* THREADS_H_ */

